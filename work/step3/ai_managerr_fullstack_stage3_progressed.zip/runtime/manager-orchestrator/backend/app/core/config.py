from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "manager-orchestrator"
    app_env: str = "local"
    simulation_mode: bool = True
    database_url: str = "postgresql+psycopg://agent:agent@postgres:5432/agent_orchestrator"
    cors_origins: str = "http://localhost:5174"
    agent_config_path: str = "/app/config/agents.yaml"
    default_timeout_seconds: int = 120

    use_router: bool = True
    router_base_url: str = "http://router:8080/v1"
    router_bearer_token: str = ""
    router_model_name: str = "router-auto"
    router_request_role_field: str = "extra_body.agent_role"

    job_mode: str = "background"  # inline | background
    worker_poll_interval_seconds: int = 2
    max_step_retry_count: int = 2

    artifact_dir: str = "/app/artifacts"

    rag_enabled: bool = False
    rag_provider: str = "local"
    rag_top_k: int = 5
    rag_timeout_seconds: int = 15

    build_runner_enabled: bool = False
    security_runner_enabled: bool = False

    schema_validation_enabled: bool = True

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @field_validator("database_url")
    @classmethod
    def validate_database_url(cls, value: str) -> str:
        if not value:
            raise ValueError("DATABASE_URL is required")
        if value.startswith("sqlite"):
            raise ValueError("SQLite is not supported in this runtime. Use PostgreSQL.")
        return value

    @field_validator("job_mode")
    @classmethod
    def validate_job_mode(cls, value: str) -> str:
        if value not in {"inline", "background"}:
            raise ValueError("JOB_MODE must be one of: inline, background")
        return value

    @property
    def cors_origins_list(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]

    @property
    def is_production(self) -> bool:
        return self.app_env.lower() not in {"local", "dev", "development", "test"}

    @property
    def artifact_path(self) -> Path:
        return Path(self.artifact_dir)


@lru_cache
def get_settings() -> Settings:
    return Settings()
