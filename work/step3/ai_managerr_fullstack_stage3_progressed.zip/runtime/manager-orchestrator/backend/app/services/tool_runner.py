from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


class ToolRunner:
    def __init__(self, artifact_dir: str | Path):
        self.artifact_dir = Path(artifact_dir)

    def run_build(self, run_id: str, step_phase: str, payload: dict[str, Any]) -> dict[str, Any]:
        workspace = self._materialize(run_id, step_phase, payload)
        file_count = sum(1 for item in workspace.rglob('*') if item.is_file())
        status = 'pass' if file_count > 0 else 'fail'
        return {
            'tool': 'build',
            'phase': step_phase,
            'status': status,
            'workspace': str(workspace),
            'file_count': file_count,
            'detail': 'workspace materialized' if file_count > 0 else 'no files materialized',
        }

    def run_test(self, run_id: str, step_phase: str, payload: dict[str, Any]) -> dict[str, Any]:
        test_cases = payload.get('test_cases') or []
        boundary_cases = payload.get('boundary_cases') or []
        regression = payload.get('regression_checklist') or []
        status = 'pass' if test_cases else 'warn'
        return {
            'tool': 'test',
            'phase': step_phase,
            'status': status,
            'test_case_count': len(test_cases),
            'boundary_case_count': len(boundary_cases),
            'regression_count': len(regression),
            'detail': 'qa checklist structured' if test_cases else 'test cases missing',
        }

    def run_lint(self, run_id: str, step_phase: str, payload: dict[str, Any]) -> dict[str, Any]:
        paths: list[str] = []
        empty_files: list[str] = []
        duplicate_paths: set[str] = set()
        seen: set[str] = set()
        for item in payload.get('files', []) + payload.get('tests', []):
            path = (item or {}).get('path', '')
            content = (item or {}).get('content', '')
            if path in seen:
                duplicate_paths.add(path)
            seen.add(path)
            paths.append(path)
            if not str(content).strip():
                empty_files.append(path)
        status = 'pass' if paths and not empty_files and not duplicate_paths else ('warn' if paths else 'fail')
        return {
            'tool': 'lint',
            'phase': step_phase,
            'status': status,
            'file_count': len(paths),
            'empty_files': sorted(filter(None, empty_files)),
            'duplicate_paths': sorted(filter(None, duplicate_paths)),
            'detail': 'basic static checks completed',
        }

    def run_scan(self, run_id: str, step_phase: str, payload: dict[str, Any]) -> dict[str, Any]:
        findings = payload.get('findings') or []
        severities: dict[str, int] = {}
        for item in findings:
            sev = str((item or {}).get('severity', 'unknown')).lower()
            severities[sev] = severities.get(sev, 0) + 1
        raw = json.dumps(payload, ensure_ascii=False)
        leaked = sorted({m.group(0) for m in re.finditer(r'(api[_-]?key|password|secret|token)', raw, flags=re.IGNORECASE)})
        status = 'pass' if findings else ('warn' if leaked else 'pass')
        return {
            'tool': 'scan',
            'phase': step_phase,
            'status': status,
            'finding_count': len(findings),
            'severities': severities,
            'keyword_hits': leaked,
            'detail': 'security findings normalized',
        }

    def _materialize(self, run_id: str, step_phase: str, payload: dict[str, Any]) -> Path:
        workspace = self.artifact_dir / 'workspaces' / run_id / step_phase
        workspace.mkdir(parents=True, exist_ok=True)
        for item in payload.get('files', []) + payload.get('tests', []):
            path = (item or {}).get('path')
            content = (item or {}).get('content', '')
            if not path:
                continue
            file_path = workspace / path
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(str(content), encoding='utf-8')
        ddl = payload.get('ddl') or []
        if ddl:
            (workspace / 'schema.sql').write_text('\n\n'.join(str(x) for x in ddl), encoding='utf-8')
        indexes = payload.get('indexes') or []
        if indexes:
            (workspace / 'indexes.sql').write_text('\n'.join(str(x) for x in indexes), encoding='utf-8')
        migration = payload.get('migration') or {}
        if migration:
            migration_name = migration.get('file', 'migration.sql')
            migration_content = migration.get('content') or json.dumps(migration, ensure_ascii=False, indent=2)
            file_path = workspace / migration_name
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_text(str(migration_content), encoding='utf-8')
        return workspace
