from datetime import datetime
from typing import Any, Optional
from uuid import UUID

from pydantic import BaseModel, Field

from app.schemas.common import EventRead


class RunCreate(BaseModel):
    project_id: Optional[UUID] = None
    title: str = Field(min_length=2, max_length=160)
    user_request: str = Field(min_length=5)
    execution_mode: str = Field(default="background")


class StepRetryRequest(BaseModel):
    mode: str = Field(default="from-step")


class ArtifactRead(BaseModel):
    id: UUID
    run_id: UUID
    step_id: Optional[UUID] = None
    artifact_type: str
    name: str
    storage_type: str
    path: Optional[str] = None
    content_type: Optional[str] = None
    summary: Optional[str] = None
    content: Optional[dict[str, Any]] = None
    created_at: datetime


class StepRead(BaseModel):
    id: UUID
    seq: int
    phase: str
    agent_code: str
    status: str
    prompt_text: Optional[str] = None
    output_text: Optional[str] = None
    input_payload: Optional[dict[str, Any]] = None
    output_payload: Optional[dict[str, Any]] = None
    error_message: Optional[str] = None
    started_at: Optional[datetime] = None
    finished_at: Optional[datetime] = None
    retry_count: int = 0
    max_retry_count: int = 0
    backend_name: Optional[str] = None
    target_model: Optional[str] = None
    schema_valid: Optional[bool] = None
    execution_ms: Optional[int] = None
    created_at: datetime


class RunRead(BaseModel):
    id: UUID
    project_id: Optional[UUID] = None
    title: str
    user_request: str
    status: str
    current_stage: Optional[str] = None
    execution_mode: str
    queue_status: Optional[str] = None
    final_summary: Optional[str] = None
    started_at: Optional[datetime] = None
    finished_at: Optional[datetime] = None
    last_error: Optional[str] = None
    run_metadata: Optional[dict[str, Any]] = None
    created_at: datetime
    updated_at: datetime
    steps: list[StepRead] = []
    events: list[EventRead] = []
    artifacts: list[ArtifactRead] = []


class RunEnqueueResponse(BaseModel):
    run_id: UUID
    status: str
    queue_status: str
    message: str


class DashboardSummary(BaseModel):
    project_count: int
    agent_count: int
    run_count: int
    running_count: int
    completed_count: int
    latest_runs: list[RunRead]
