from datetime import datetime
from typing import Optional
from uuid import UUID

from pydantic import BaseModel, Field


class ProjectCreate(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    description: Optional[str] = None


class ProjectRead(BaseModel):
    id: UUID
    name: str
    description: Optional[str] = None
    created_at: datetime
    updated_at: datetime


class ProjectKnowledgeCreate(BaseModel):
    title: str = Field(min_length=2, max_length=160)
    content: str = Field(min_length=1)
    source_type: str = Field(default="note", max_length=40)
    tags: list[str] = Field(default_factory=list)
    summary: Optional[str] = None


class ProjectKnowledgeRead(BaseModel):
    id: UUID
    project_id: UUID
    title: str
    source_type: str
    tags: Optional[list[str]] = None
    content: str
    summary: Optional[str] = None
    created_at: datetime
    updated_at: datetime
