from pathlib import Path

from app.services.tool_runner import ToolRunner


def test_tool_runner_materializes_dev_files(tmp_path: Path):
    runner = ToolRunner(tmp_path)
    payload = {
        'files': [{'path': 'src/App.tsx', 'content': 'export default function App() { return null; }'}],
        'tests': [{'path': 'src/App.test.tsx', 'content': 'describe("App", () => {})'}],
    }
    build = runner.run_build('run-1', 'dev-fe', payload)
    lint = runner.run_lint('run-1', 'dev-fe', payload)
    assert build['status'] == 'pass'
    assert lint['status'] == 'pass'
    assert (tmp_path / 'workspaces' / 'run-1' / 'dev-fe' / 'src' / 'App.tsx').exists()
