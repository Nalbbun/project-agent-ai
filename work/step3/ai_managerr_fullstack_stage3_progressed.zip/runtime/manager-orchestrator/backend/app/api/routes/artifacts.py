from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlmodel import Session, select

from app.api.deps import get_db_session
from app.models.artifact import Artifact
from app.schemas.run import ArtifactRead

router = APIRouter(tags=["artifacts"])


@router.get("/runs/{run_id}/artifacts", response_model=list[ArtifactRead])
def list_artifacts(run_id: str, session: Session = Depends(get_db_session)) -> list[Artifact]:
    run_uuid = UUID(run_id)
    return session.exec(
        select(Artifact)
        .where(Artifact.run_id == run_uuid)
        .order_by(Artifact.created_at.asc())
    ).all()


@router.get("/artifacts/{artifact_id}", response_model=ArtifactRead)
def get_artifact(artifact_id: str, session: Session = Depends(get_db_session)) -> Artifact:
    artifact = session.get(Artifact, UUID(artifact_id))
    if not artifact:
        raise HTTPException(status_code=404, detail="Artifact not found")
    return artifact
