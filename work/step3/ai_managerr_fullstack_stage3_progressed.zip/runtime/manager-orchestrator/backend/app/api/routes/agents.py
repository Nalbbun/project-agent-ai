from fastapi import APIRouter, Depends
from sqlmodel import Session, select

from app.api.deps import get_db_session
from app.models.agent import AgentCatalog
from app.schemas.agent import AgentRead

router = APIRouter(tags=["agents"])


@router.get("/agents", response_model=list[AgentRead])
def list_agents(session: Session = Depends(get_db_session)) -> list[AgentCatalog]:
    return session.exec(select(AgentCatalog).order_by(AgentCatalog.code)).all()
