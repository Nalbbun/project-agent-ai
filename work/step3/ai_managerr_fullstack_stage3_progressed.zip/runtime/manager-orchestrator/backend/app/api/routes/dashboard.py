from fastapi import APIRouter, Depends
from sqlmodel import Session, select

from app.api.deps import get_db_session
from app.models.agent import AgentCatalog
from app.models.project import Project
from app.models.run import OrchestrationRun
from app.schemas.run import DashboardSummary
from app.services.run_reader import build_run_read

router = APIRouter(tags=["dashboard"])


@router.get("/dashboard", response_model=DashboardSummary)
def get_dashboard(session: Session = Depends(get_db_session)) -> DashboardSummary:
    runs = session.exec(select(OrchestrationRun).order_by(OrchestrationRun.created_at.desc())).all()
    latest_runs = [build_run_read(session, run) for run in runs[:5]]
    return DashboardSummary(
        project_count=len(session.exec(select(Project)).all()),
        agent_count=len(session.exec(select(AgentCatalog)).all()),
        run_count=len(runs),
        running_count=sum(1 for r in runs if r.queue_status in {"queued", "resuming", "running"}),
        completed_count=sum(1 for r in runs if r.status == "completed"),
        latest_runs=latest_runs,
    )
