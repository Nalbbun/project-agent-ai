from __future__ import annotations

import time

from sqlmodel import Session

from app.core.config import get_settings
from app.db.session import engine, wait_for_db
from app.services.job_queue import JobQueueService
from app.services.orchestrator import OrchestratorService
from app.services.seed import seed_agents_from_yaml

settings = get_settings()


def main() -> None:
    wait_for_db()
    seed_agents_from_yaml()
    while True:
        with Session(engine) as session:
            queue = JobQueueService(session)
            run = queue.next_pending_run()
            if run:
                orchestrator = OrchestratorService(session)
                orchestrator.execute_run_inline(run.id)
        time.sleep(settings.worker_poll_interval_seconds)


if __name__ == "__main__":
    main()
