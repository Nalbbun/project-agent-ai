import { NavLink, Outlet } from 'react-router-dom';

const navItems = [
  { to: '/', label: 'Dashboard' },
  { to: '/runs', label: 'Runs' },
  { to: '/agents', label: 'Agents' },
];

export default function Layout() {
  return (
    <div className="layout">
      <aside className="sidebar">
        <h1>Manager / Orchestrator</h1>
        <p className="muted">PM · Architect · Dev · QA · SecOps 관리 콘솔</p>
        <nav>
          {navItems.map((item) => (
            <NavLink key={item.to} to={item.to} className={({ isActive }) => isActive ? 'nav-link active' : 'nav-link'}>
              {item.label}
            </NavLink>
          ))}
        </nav>
      </aside>
      <main className="content">
        <Outlet />
      </main>
    </div>
  );
}
