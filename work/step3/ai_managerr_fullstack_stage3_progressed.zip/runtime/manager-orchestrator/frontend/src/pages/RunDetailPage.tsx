import { useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import { api } from '../api/client';
import RunTimeline from '../components/RunTimeline';
import type { Artifact, Run } from '../types';

const ACTIVE_QUEUE_STATUSES = new Set(['queued', 'resuming', 'running']);

export default function RunDetailPage() {
  const { runId = '' } = useParams();
  const [run, setRun] = useState<Run | null>(null);
  const [artifacts, setArtifacts] = useState<Artifact[]>([]);
  const [busy, setBusy] = useState(false);
  const [selectedArtifactId, setSelectedArtifactId] = useState<string | null>(null);

  const isActive = useMemo(() => Boolean(run?.queue_status && ACTIVE_QUEUE_STATUSES.has(run.queue_status)), [run?.queue_status]);

  const load = async () => {
    const [runData, artifactData] = await Promise.all([api.run(runId), api.artifacts(runId)]);
    setRun(runData as Run);
    setArtifacts(artifactData as Artifact[]);
  };

  useEffect(() => {
    load().catch(console.error);
  }, [runId]);

  useEffect(() => {
    if (!isActive) return;
    const timer = window.setInterval(() => {
      load().catch(console.error);
    }, 3000);
    return () => window.clearInterval(timer);
  }, [isActive, runId]);

  const execute = async () => {
    setBusy(true);
    try {
      await api.executeRun(runId);
      await load();
    } finally {
      setBusy(false);
    }
  };

  const retry = async () => {
    setBusy(true);
    try {
      await api.retryRun(runId);
      await load();
    } finally {
      setBusy(false);
    }
  };

  const resume = async () => {
    setBusy(true);
    try {
      await api.resumeRun(runId);
      await load();
    } finally {
      setBusy(false);
    }
  };

  const cancel = async () => {
    setBusy(true);
    try {
      await api.cancelRun(runId);
      await load();
    } finally {
      setBusy(false);
    }
  };

  const retryStep = async (stepId: string) => {
    setBusy(true);
    try {
      await api.retryStep(runId, stepId);
      await load();
    } finally {
      setBusy(false);
    }
  };

  if (!run) return <div>Loading...</div>;

  return (
    <div className="page">
      <header className="page-header split">
        <div>
          <h2>{run.title}</h2>
          <p className="muted">status: {run.status} / queue: {run.queue_status ?? '-'} / current: {run.current_stage ?? '-'}</p>
        </div>
        <div className="actions">
          <button onClick={execute} disabled={busy || isActive}>{busy ? '처리 중...' : '실행 요청'}</button>
          <button className="secondary" onClick={retry} disabled={busy}>전체 재시도</button>
          <button className="secondary" onClick={resume} disabled={busy}>Resume</button>
          <button className="secondary" onClick={cancel} disabled={busy || !isActive}>Cancel</button>
        </div>
      </header>

      <section className="card">
        <h3>사용자 요구</h3>
        <p>{run.user_request}</p>
        <div className="muted">execution_mode: {run.execution_mode} / started: {run.started_at ? new Date(run.started_at).toLocaleString() : '-'} / finished: {run.finished_at ? new Date(run.finished_at).toLocaleString() : '-'}</div>
        {run.last_error && <div className="error-box">{run.last_error}</div>}
        {run.final_summary && (
          <>
            <h4>Final Summary</h4>
            <p>{run.final_summary}</p>
          </>
        )}
      </section>

      <section className="card">
        <h3>Step Timeline</h3>
        <RunTimeline steps={run.steps} onRetryStep={retryStep} />
      </section>

      <section className="card">
        <h3>Artifacts</h3>
        <div className="list-grid">
          {artifacts.map((artifact) => (
            <button type="button" key={artifact.id} className="list-item" onClick={() => setSelectedArtifactId(selectedArtifactId === artifact.id ? null : artifact.id)}>
              <strong>{artifact.name}</strong>
              <span className="muted">type: {artifact.artifact_type} / storage: {artifact.storage_type}</span>
              <span className="muted">summary: {artifact.summary ?? '-'}</span>
              {selectedArtifactId === artifact.id && <pre className="artifact-preview">{JSON.stringify(artifact.content ?? {}, null, 2)}</pre>}
            </button>
          ))}
        </div>
      </section>

      <section className="card">
        <h3>Event Logs</h3>
        <div className="log-list">
          {run.events.map((event) => (
            <div key={event.id} className={`log-item ${event.level}`}>
              <strong>[{event.level}]</strong> {event.event_type} - {event.message}
              <div className="muted">{new Date(event.created_at).toLocaleString()}</div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
