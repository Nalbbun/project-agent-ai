import type { Artifact, RunEnqueueResponse } from '../types';

const API_BASE = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8080/api';

async function request<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE}${url}`, {
    headers: { 'Content-Type': 'application/json' },
    ...init,
  });
  if (!response.ok) {
    const text = await response.text();
    throw new Error(text || 'Request failed');
  }
  return response.json() as Promise<T>;
}

export const api = {
  dashboard: () => request('/dashboard'),
  agents: () => request('/agents'),
  projects: () => request('/projects'),
  createProject: (body: { name: string; description?: string }) =>
    request('/projects', { method: 'POST', body: JSON.stringify(body) }),
  projectKnowledge: (projectId: string) => request(`/projects/${projectId}/knowledge`),
  createProjectKnowledge: (projectId: string, body: { title: string; content: string; source_type?: string; tags?: string[]; summary?: string }) =>
    request(`/projects/${projectId}/knowledge`, { method: 'POST', body: JSON.stringify(body) }),
  runs: () => request('/runs'),
  run: (id: string) => request(`/runs/${id}`),
  createRun: (body: { project_id?: string | null; title: string; user_request: string; execution_mode?: string }) =>
    request('/runs', { method: 'POST', body: JSON.stringify(body) }),
  executeRun: (id: string) => request<RunEnqueueResponse>(`/runs/${id}/execute`, { method: 'POST' }),
  retryRun: (id: string) => request<RunEnqueueResponse>(`/runs/${id}/retry`, { method: 'POST' }),
  cancelRun: (id: string) => request(`/runs/${id}/cancel`, { method: 'POST' }),
  resumeRun: (id: string) => request<RunEnqueueResponse>(`/runs/${id}/resume`, { method: 'POST' }),
  retryStep: (runId: string, stepId: string, mode = 'from-step') =>
    request<RunEnqueueResponse>(`/runs/${runId}/steps/${stepId}/retry`, { method: 'POST', body: JSON.stringify({ mode }) }),
  artifacts: (runId: string) => request<Artifact[]>(`/runs/${runId}/artifacts`),
};
