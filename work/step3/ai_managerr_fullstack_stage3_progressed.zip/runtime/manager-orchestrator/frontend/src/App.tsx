import { Route, Routes } from 'react-router-dom';
import Layout from './components/Layout';
import AgentsPage from './pages/AgentsPage';
import DashboardPage from './pages/DashboardPage';
import RunDetailPage from './pages/RunDetailPage';
import RunsPage from './pages/RunsPage';

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<DashboardPage />} />
        <Route path="/agents" element={<AgentsPage />} />
        <Route path="/runs" element={<RunsPage />} />
        <Route path="/runs/:runId" element={<RunDetailPage />} />
      </Route>
    </Routes>
  );
}
