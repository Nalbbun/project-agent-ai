export type Project = {
  id: string;
  name: string;
  description?: string | null;
  created_at: string;
  updated_at: string;
};

export type Agent = {
  id: string;
  code: string;
  name: string;
  role: string;
  endpoint: string;
  model: string;
  adapter?: string | null;
  prompt_key: string;
  transport: string;
  router_role: string;
  request_timeout_seconds: number;
  max_retries: number;
  active: boolean;
  created_at: string;
  updated_at: string;
};

export type RunStep = {
  id: string;
  seq: number;
  phase: string;
  agent_code: string;
  status: string;
  prompt_text?: string | null;
  output_text?: string | null;
  input_payload?: Record<string, unknown> | null;
  output_payload?: Record<string, unknown> | null;
  error_message?: string | null;
  started_at?: string | null;
  finished_at?: string | null;
  retry_count: number;
  max_retry_count: number;
  backend_name?: string | null;
  target_model?: string | null;
  schema_valid?: boolean | null;
  execution_ms?: number | null;
  created_at: string;
};

export type RunEvent = {
  id: string;
  run_id: string;
  step_id?: string | null;
  level: string;
  event_type: string;
  message: string;
  trace_id?: string | null;
  request_id?: string | null;
  payload?: Record<string, unknown> | null;
  created_at: string;
};

export type Artifact = {
  id: string;
  run_id: string;
  step_id?: string | null;
  artifact_type: string;
  name: string;
  storage_type: string;
  path?: string | null;
  content_type?: string | null;
  summary?: string | null;
  content?: Record<string, unknown> | null;
  created_at: string;
};

export type Run = {
  id: string;
  project_id?: string | null;
  title: string;
  user_request: string;
  status: string;
  current_stage?: string | null;
  execution_mode: string;
  queue_status?: string | null;
  final_summary?: string | null;
  started_at?: string | null;
  finished_at?: string | null;
  last_error?: string | null;
  run_metadata?: Record<string, unknown> | null;
  created_at: string;
  updated_at: string;
  steps: RunStep[];
  events: RunEvent[];
  artifacts: Artifact[];
};

export type RunEnqueueResponse = {
  run_id: string;
  status: string;
  queue_status: string;
  message: string;
};

export type DashboardSummary = {
  project_count: number;
  agent_count: number;
  run_count: number;
  running_count: number;
  completed_count: number;
  latest_runs: Run[];
};


export type ProjectKnowledge = {
  id: string;
  project_id: string;
  title: string;
  source_type: string;
  tags?: string[];
  content: string;
  summary?: string;
  created_at: string;
  updated_at: string;
};
