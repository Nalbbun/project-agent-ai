# AI Agent Platform Monorepo

이 패키지는 **학습 패키지(learning)** 와 **운영 패키지(runtime)** 를 분리한 실무형 스타터입니다.

## 구성 개요

- `learning/`
  - 업로드된 `ai_agent_work.zip` 기준 학습용 스키마, reward, SFT/GRPO 스크립트, serving 샘플을 그대로 포함
- `runtime/manager-orchestrator/`
  - Manager / Orchestrator 전체 소스
  - `backend/`: FastAPI + SQLModel + OpenAI-compatible LLM Router
  - `frontend/`: React + Vite + TypeScript 운영 UI
  - `db/`: PostgreSQL init SQL
  - `config/`: 에이전트/라우팅 YAML
  - `docker-compose.yml`: postgres + backend + frontend 로컬 구동

## 설계 기준

- 역할 분리: PM / Architect / Dev-FE / Dev-BE / Dev-DB / QA / SecOps / Manager
- Manager는 계획 수립, 단계 실행, 결과 병합을 담당
- Dev는 FE/BE/DB로 분리
- Tool Layer 연동을 전제로 API/DB/이벤트 구조 설계
- 실제 모델 연결 전에도 테스트할 수 있도록 `SIMULATION_MODE=true` 지원

## 빠른 실행

```bash
cd runtime/manager-orchestrator
cp .env.example .env
docker compose up --build
```

- Backend: http://localhost:8080/docs
- Frontend: http://localhost:5174
- Postgres: localhost:5432

## 기본 동작 흐름

1. 프로젝트 생성
2. 사용자 요구로 Run 생성
3. Manager planning step 실행
4. PM → Architect → Dev-FE → Dev-BE → Dev-DB → QA → SecOps → Manager merge 순서로 단계 수행
5. 각 step 결과와 이벤트 로그를 DB에 저장

## 실제 모델 연동

`.env` 와 `config/agents.yaml` 의 endpoint/model/adapter를 vLLM/Ollama/OpenAI-compatible 서버에 맞춰 수정하면 됩니다.

## 주의

이 소스는 **실행 가능한 스타터/골격**입니다. 실제 사내 표준, 인증, 보안, RAG, sandbox, test runner, artifact storage는 추가 연동이 필요합니다.
