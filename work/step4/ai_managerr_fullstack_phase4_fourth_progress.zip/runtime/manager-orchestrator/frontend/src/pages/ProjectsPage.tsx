import { FormEvent, useEffect, useMemo, useState } from 'react';
import { api } from '../api/client';
import type { Project, ProjectKnowledge, ProjectMembership, ProjectSummary, User } from '../types';

export default function ProjectsPage() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<string>('');
  const [knowledge, setKnowledge] = useState<ProjectKnowledge[]>([]);
  const [memberships, setMemberships] = useState<ProjectMembership[]>([]);
  const [summary, setSummary] = useState<ProjectSummary | null>(null);
  const [memberFilter, setMemberFilter] = useState('');
  const [form, setForm] = useState({ name: '', description: '' });
  const [knowledgeForm, setKnowledgeForm] = useState({ title: '', content: '' });
  const [membershipForm, setMembershipForm] = useState({ user_id: '', access_role: 'viewer' });

  const loadProjects = async () => {
    const rows = await api.projects();
    setProjects(rows as Project[]);
    if (!selectedProjectId && rows[0]?.id) setSelectedProjectId(rows[0].id);
  };

  const refreshProjectData = async (projectId: string) => {
    const [knowledgeRows, membershipRows, summaryRow] = await Promise.all([
      api.projectKnowledge(projectId),
      api.projectMemberships(projectId),
      api.projectSummary(projectId),
    ]);
    setKnowledge(knowledgeRows as ProjectKnowledge[]);
    setMemberships(membershipRows);
    setSummary(summaryRow);
  };

  useEffect(() => { loadProjects().catch(console.error); api.users().then(setUsers).catch(() => setUsers([])); }, []);
  useEffect(() => {
    if (!selectedProjectId) return;
    refreshProjectData(selectedProjectId).catch(console.error);
  }, [selectedProjectId]);

  const createProject = async (e: FormEvent) => {
    e.preventDefault();
    await api.createProject(form);
    setForm({ name: '', description: '' });
    await loadProjects();
  };

  const createKnowledge = async (e: FormEvent) => {
    e.preventDefault();
    if (!selectedProjectId) return;
    await api.createProjectKnowledge(selectedProjectId, knowledgeForm);
    setKnowledgeForm({ title: '', content: '' });
    await refreshProjectData(selectedProjectId);
  };

  const addMembership = async (e: FormEvent) => {
    e.preventDefault();
    if (!selectedProjectId || !membershipForm.user_id) return;
    await api.createProjectMembership(selectedProjectId, membershipForm);
    setMembershipForm({ user_id: '', access_role: 'viewer' });
    await refreshProjectData(selectedProjectId);
  };

  const removeMembership = async (membershipId: string) => {
    if (!selectedProjectId) return;
    await api.deleteProjectMembership(selectedProjectId, membershipId);
    await refreshProjectData(selectedProjectId);
  };

  const deleteKnowledge = async (knowledgeId: string) => {
    if (!selectedProjectId) return;
    await api.deleteProjectKnowledge(selectedProjectId, knowledgeId);
    await refreshProjectData(selectedProjectId);
  };

  const filteredMemberships = useMemo(() => memberships.filter((item) => {
    const user = users.find((u) => u.id === item.user_id);
    const q = memberFilter.trim().toLowerCase();
    if (!q) return true;
    return (user?.display_name ?? '').toLowerCase().includes(q) || (user?.username ?? '').toLowerCase().includes(q) || item.access_role.toLowerCase().includes(q);
  }), [memberships, users, memberFilter]);

  return (
    <div className="page two-column">
      <section className="card form-card">
        <h3>Create Project</h3>
        <form onSubmit={createProject}>
          <label>Name<input value={form.name} onChange={(e) => setForm((prev) => ({ ...prev, name: e.target.value }))} /></label>
          <label>Description<textarea rows={4} value={form.description} onChange={(e) => setForm((prev) => ({ ...prev, description: e.target.value }))} /></label>
          <button type="submit">프로젝트 생성</button>
        </form>
        <h3 style={{ marginTop: 24 }}>Projects</h3>
        <div className="list-grid">
          {projects.map((project) => (
            <button type="button" key={project.id} className={`list-item ${selectedProjectId === project.id ? 'selected' : ''}`} onClick={() => setSelectedProjectId(project.id)}>
              <strong>{project.name}</strong>
              <span className="muted">{project.description ?? '-'}</span>
            </button>
          ))}
        </div>
      </section>
      <section className="page">
        <div className="card">
          <div className="split">
            <h3>Project Summary</h3>
            {selectedProjectId && <button className="secondary" onClick={() => api.reindexProjectKnowledge(selectedProjectId).then(() => refreshProjectData(selectedProjectId)).catch(console.error)}>Reindex Knowledge</button>}
          </div>
          {summary ? (
            <div className="stat-grid compact">
              <div className="card"><strong>My Access</strong><div>{summary.my_access_role ?? '-'}</div></div>
              <div className="card"><strong>Knowledge</strong><div>{summary.knowledge_count}</div></div>
              <div className="card"><strong>Members</strong><div>{summary.membership_count}</div></div>
              <div className="card"><strong>Runs</strong><div>{summary.run_count}</div></div>
              <div className="card"><strong>Waiting Approval</strong><div>{summary.waiting_approval_count}</div></div>
            </div>
          ) : <div className="muted">프로젝트를 선택하세요.</div>}
        </div>
        <div className="card">
          <h3>Knowledge</h3>
          <form onSubmit={createKnowledge}>
            <label>Title<input value={knowledgeForm.title} onChange={(e) => setKnowledgeForm((prev) => ({ ...prev, title: e.target.value }))} /></label>
            <label>Content<textarea rows={5} value={knowledgeForm.content} onChange={(e) => setKnowledgeForm((prev) => ({ ...prev, content: e.target.value }))} /></label>
            <button type="submit" disabled={!selectedProjectId}>지식 추가</button>
          </form>
          <div className="list-grid" style={{ marginTop: 16 }}>
            {knowledge.map((item) => (
              <div key={item.id} className="list-item">
                <div className="split">
                  <strong>{item.title}</strong>
                  <button className="secondary" type="button" onClick={() => deleteKnowledge(item.id)}>삭제</button>
                </div>
                <span className="muted">{item.source_type}</span>
                <pre className="artifact-preview">{item.content}</pre>
              </div>
            ))}
          </div>
        </div>
        <div className="card">
          <h3>Memberships</h3>
          <form onSubmit={addMembership}>
            <label>User<select value={membershipForm.user_id} onChange={(e) => setMembershipForm((prev) => ({ ...prev, user_id: e.target.value }))}>
              <option value="">선택</option>
              {users.map((user) => <option key={user.id} value={user.id}>{user.display_name} ({user.role})</option>)}
            </select></label>
            <label>Access Role<select value={membershipForm.access_role} onChange={(e) => setMembershipForm((prev) => ({ ...prev, access_role: e.target.value }))}>
              <option value="viewer">viewer</option>
              <option value="reviewer">reviewer</option>
              <option value="editor">editor</option>
              <option value="owner">owner</option>
            </select></label>
            <button type="submit" disabled={!selectedProjectId}>멤버 추가</button>
          </form>
          <label style={{ marginTop: 12 }}>Filter
            <input value={memberFilter} onChange={(e) => setMemberFilter(e.target.value)} placeholder="name / username / role" />
          </label>
          <div className="list-grid" style={{ marginTop: 16 }}>
            {filteredMemberships.map((item) => {
              const user = users.find((u) => u.id === item.user_id);
              return (
                <div key={item.id} className="list-item">
                  <div className="split">
                    <strong>{user?.display_name ?? item.user_id}</strong>
                    <button className="secondary" type="button" onClick={() => removeMembership(item.id)}>제거</button>
                  </div>
                  <span className="muted">username: {user?.username ?? '-'}</span>
                  <span className="muted">global role: {user?.role ?? '-'}</span>
                  <span className="muted">project role: {item.access_role}</span>
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </div>
  );
}
