from __future__ import annotations

from datetime import datetime
from typing import Optional
from uuid import UUID

from pydantic import BaseModel, Field


class ProjectCreate(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    description: Optional[str] = None


class ProjectRead(BaseModel):
    id: UUID
    name: str
    description: Optional[str] = None
    created_at: datetime
    updated_at: datetime


class ProjectKnowledgeCreate(BaseModel):
    title: str = Field(min_length=2, max_length=160)
    source_type: str = Field(default="note", max_length=40)
    tags: list[str] | None = None
    content: str = Field(min_length=1)
    summary: Optional[str] = None


class ProjectKnowledgeRead(BaseModel):
    id: UUID
    project_id: UUID
    title: str
    source_type: str
    tags: list[str] | None = None
    content: str
    summary: Optional[str] = None
    created_at: datetime
    updated_at: datetime


class ProjectMembershipCreate(BaseModel):
    user_id: UUID
    access_role: str = Field(default="viewer", max_length=30)


class ProjectMembershipRead(BaseModel):
    id: UUID
    project_id: UUID
    user_id: UUID
    access_role: str
    granted_by_user_id: UUID | None = None
    created_at: datetime



class ProjectSummaryRead(BaseModel):
    project_id: UUID
    knowledge_count: int = 0
    membership_count: int = 0
    run_count: int = 0
    waiting_approval_count: int = 0
    my_access_role: str | None = None
