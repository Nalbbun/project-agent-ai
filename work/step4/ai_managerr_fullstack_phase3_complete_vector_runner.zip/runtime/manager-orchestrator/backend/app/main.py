from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text

from app.api.routes import agents, artifacts, dashboard, projects, runs
from app.core.config import get_settings
from app.db.session import engine, wait_for_db
from app.services.seed import seed_agents_from_yaml
from app.services.vector_store import VectorStoreService

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    wait_for_db()
    settings.artifact_path.mkdir(parents=True, exist_ok=True)
    seed_agents_from_yaml()
    if settings.vector_store_enabled:
        VectorStoreService().ensure_collections()
    yield


app = FastAPI(
    title=settings.app_name,
    version="0.4.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health/live")
def health_live() -> dict:
    return {"status": "ok", "simulation_mode": settings.simulation_mode}


@app.get("/health/ready")
def health_ready() -> dict:
    with engine.connect() as conn:
        conn.execute(text("SELECT 1"))
    vector_status = VectorStoreService().health()
    return {
        "status": "ready",
        "simulation_mode": settings.simulation_mode,
        "job_mode": settings.job_mode,
        "router_base_url": settings.router_base_url,
        "artifact_dir": str(settings.artifact_path),
        "vector_store": vector_status,
    }


@app.get("/health")
def health() -> dict:
    return {
        "status": "ok",
        "simulation_mode": settings.simulation_mode,
        "vector_store": VectorStoreService().health(),
    }


app.include_router(dashboard.router, prefix="/api")
app.include_router(agents.router, prefix="/api")
app.include_router(projects.router, prefix="/api")
app.include_router(runs.router, prefix="/api")
app.include_router(artifacts.router, prefix="/api")
