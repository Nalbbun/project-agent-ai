from datetime import datetime
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlmodel import Session, select

from app.api.deps import get_db_session, require_roles
from app.models.artifact import Artifact
from app.models.project import Project
from app.models.project_knowledge import ProjectKnowledge
from app.models.run import OrchestrationRun
from app.models.user_account import UserAccount
from app.schemas.project import (
    ProjectCreate,
    ProjectKnowledgeCreate,
    ProjectKnowledgeRead,
    ProjectRead,
)
from app.services.vector_store import VectorStoreService

router = APIRouter(tags=["projects"])


@router.get("/projects", response_model=list[ProjectRead])
def list_projects(session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator", "reviewer", "viewer"))) -> list[Project]:
    return session.exec(select(Project).order_by(Project.created_at.desc())).all()


@router.post("/projects", response_model=ProjectRead, status_code=status.HTTP_201_CREATED)
def create_project(payload: ProjectCreate, session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator"))) -> Project:
    project = Project(name=payload.name, description=payload.description, updated_at=datetime.utcnow())
    session.add(project)
    session.commit()
    session.refresh(project)
    return project


@router.get("/projects/{project_id}", response_model=ProjectRead)
def get_project(project_id: str, session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator", "reviewer", "viewer"))) -> Project:
    project = session.get(Project, UUID(project_id))
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return project


@router.get("/projects/{project_id}/knowledge", response_model=list[ProjectKnowledgeRead])
def list_project_knowledge(project_id: str, session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator", "reviewer", "viewer"))) -> list[ProjectKnowledge]:
    project_uuid = UUID(project_id)
    if not session.get(Project, project_uuid):
        raise HTTPException(status_code=404, detail="Project not found")
    return session.exec(
        select(ProjectKnowledge)
        .where(ProjectKnowledge.project_id == project_uuid)
        .order_by(ProjectKnowledge.created_at.desc())
    ).all()


@router.post("/projects/{project_id}/knowledge", response_model=ProjectKnowledgeRead, status_code=status.HTTP_201_CREATED)
def create_project_knowledge(project_id: str, payload: ProjectKnowledgeCreate, session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator"))) -> ProjectKnowledge:
    project_uuid = UUID(project_id)
    if not session.get(Project, project_uuid):
        raise HTTPException(status_code=404, detail="Project not found")
    item = ProjectKnowledge(
        project_id=project_uuid,
        title=payload.title,
        content=payload.content,
        source_type=payload.source_type,
        tags=payload.tags,
        summary=payload.summary,
    )
    session.add(item)
    session.commit()
    session.refresh(item)
    VectorStoreService().upsert_project_knowledge(item)
    return item


@router.post("/projects/{project_id}/knowledge/reindex")
def reindex_project_knowledge(project_id: str, session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator"))) -> dict:
    project_uuid = UUID(project_id)
    if not session.get(Project, project_uuid):
        raise HTTPException(status_code=404, detail="Project not found")
    vector = VectorStoreService()
    docs = session.exec(select(ProjectKnowledge).where(ProjectKnowledge.project_id == project_uuid)).all()
    for doc in docs:
        vector.upsert_project_knowledge(doc)
    artifacts = session.exec(
        select(Artifact)
        .join(OrchestrationRun, Artifact.run_id == OrchestrationRun.id)
        .where(OrchestrationRun.project_id == project_uuid)
    ).all()
    for artifact in artifacts:
        vector.upsert_artifact(artifact, project_id=project_uuid)
    return {"message": "Project knowledge reindexed", "knowledge_count": len(docs), "artifact_count": len(artifacts)}


@router.get("/projects/{project_id}/knowledge/{knowledge_id}", response_model=ProjectKnowledgeRead)
def get_project_knowledge(project_id: str, knowledge_id: str, session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator", "reviewer", "viewer"))) -> ProjectKnowledge:
    project_uuid = UUID(project_id)
    item = session.get(ProjectKnowledge, UUID(knowledge_id))
    if not item or item.project_id != project_uuid:
        raise HTTPException(status_code=404, detail="Knowledge not found")
    return item


@router.delete("/projects/{project_id}/knowledge/{knowledge_id}")
def delete_project_knowledge(project_id: str, knowledge_id: str, session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator"))) -> dict:
    project_uuid = UUID(project_id)
    item = session.get(ProjectKnowledge, UUID(knowledge_id))
    if not item or item.project_id != project_uuid:
        raise HTTPException(status_code=404, detail="Knowledge not found")
    VectorStoreService().delete_project_knowledge(item.id)
    session.delete(item)
    session.commit()
    return {"message": "Knowledge deleted"}
