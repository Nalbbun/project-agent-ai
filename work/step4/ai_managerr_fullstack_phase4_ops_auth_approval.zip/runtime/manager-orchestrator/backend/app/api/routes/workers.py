from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlmodel import Session

from app.api.deps import get_db_session, require_roles
from app.models.user_account import UserAccount
from app.schemas.worker import WorkerRead
from app.services.worker_service import WorkerService

router = APIRouter(tags=["workers"])


@router.get("/workers", response_model=list[WorkerRead])
def list_workers(session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator", "reviewer", "viewer"))) -> list[WorkerRead]:
    rows = WorkerService(session).list_workers()
    return [WorkerRead.model_validate(row, from_attributes=True) for row in rows]
