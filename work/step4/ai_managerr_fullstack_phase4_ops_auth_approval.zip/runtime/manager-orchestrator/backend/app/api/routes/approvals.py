from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends
from sqlmodel import Session

from app.api.deps import get_db_session, require_roles
from app.models.user_account import UserAccount
from app.schemas.approval import ApprovalDecisionRequest, ApprovalRead
from app.services.approval_service import ApprovalService

router = APIRouter(tags=["approvals"])


@router.get("/runs/{run_id}/approvals", response_model=list[ApprovalRead])
def list_approvals(run_id: str, session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator", "reviewer", "viewer"))) -> list[ApprovalRead]:
    rows = ApprovalService(session).list_for_run(UUID(run_id))
    return [ApprovalRead.model_validate(row, from_attributes=True) for row in rows]


@router.post("/runs/{run_id}/approvals/{approval_id}/approve", response_model=ApprovalRead)
def approve(run_id: str, approval_id: str, body: ApprovalDecisionRequest, session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "reviewer"))) -> ApprovalRead:
    row = ApprovalService(session).decide(UUID(run_id), UUID(approval_id), user.id, "approved", body.note)
    return ApprovalRead.model_validate(row, from_attributes=True)


@router.post("/runs/{run_id}/approvals/{approval_id}/reject", response_model=ApprovalRead)
def reject(run_id: str, approval_id: str, body: ApprovalDecisionRequest, session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "reviewer"))) -> ApprovalRead:
    row = ApprovalService(session).decide(UUID(run_id), UUID(approval_id), user.id, "rejected", body.note)
    return ApprovalRead.model_validate(row, from_attributes=True)
