from __future__ import annotations

from typing import Callable

from fastapi import Depends, Header, HTTPException, status
from sqlmodel import Session

from app.db.session import get_session
from app.models.user_account import UserAccount
from app.services.auth import AuthService


def get_db_session(session: Session = Depends(get_session)) -> Session:
    return session


def get_current_user(
    authorization: str | None = Header(default=None),
    session: Session = Depends(get_db_session),
) -> UserAccount:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing bearer token")
    token = authorization.split(" ", 1)[1].strip()
    return AuthService(session).resolve_token(token)


def require_roles(*roles: str) -> Callable:
    def _dependency(user: UserAccount = Depends(get_current_user)) -> UserAccount:
        if user.role not in roles:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Insufficient role")
        return user
    return _dependency
