from fastapi import APIRouter, Depends
from sqlmodel import Session, select

from app.api.deps import get_db_session, require_roles
from app.models.agent import AgentCatalog
from app.models.project import Project
from app.models.run import OrchestrationRun
from app.models.user_account import UserAccount
from app.schemas.run import DashboardSummary
from app.services.run_reader import build_run_read
from app.services.worker_service import WorkerService

router = APIRouter(tags=["dashboard"])


@router.get("/dashboard", response_model=DashboardSummary)
def get_dashboard(session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator", "reviewer", "viewer"))) -> DashboardSummary:
    runs = session.exec(select(OrchestrationRun).order_by(OrchestrationRun.created_at.desc())).all()
    latest_runs = [build_run_read(session, run) for run in runs[:5]]
    worker_summary = WorkerService(session).summarize()
    return DashboardSummary(
        project_count=len(session.exec(select(Project)).all()),
        agent_count=len(session.exec(select(AgentCatalog)).all()),
        run_count=len(runs),
        running_count=sum(1 for r in runs if r.queue_status in {"queued", "resuming", "running", "retry_scheduled", "waiting_approval"}),
        completed_count=sum(1 for r in runs if r.status == "completed"),
        worker_count=worker_summary["worker_count"],
        active_worker_count=worker_summary["active_worker_count"],
        latest_runs=latest_runs,
    )
