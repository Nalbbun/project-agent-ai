from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlmodel import Session, select

from app.api.deps import get_db_session, require_roles
from app.models.event import OrchestrationEvent
from app.models.run import OrchestrationRun
from app.models.user_account import UserAccount
from app.schemas.common import EventRead, MessageResponse
from app.schemas.run import RunCreate, RunEnqueueResponse, RunRead, StepRetryRequest
from app.services.orchestrator import OrchestratorService
from app.services.run_reader import build_run_read

router = APIRouter(tags=["runs"])


@router.get("/runs", response_model=list[RunRead])
def list_runs(session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator", "reviewer", "viewer"))) -> list[RunRead]:
    runs = session.exec(select(OrchestrationRun).order_by(OrchestrationRun.created_at.desc())).all()
    return [build_run_read(session, run) for run in runs]


@router.post("/runs", response_model=RunRead, status_code=status.HTTP_201_CREATED)
def create_run(payload: RunCreate, session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator"))) -> RunRead:
    svc = OrchestratorService(session)
    run = svc.create_run(payload, requested_by_user_id=user.id)
    return build_run_read(session, run)


@router.get("/runs/{run_id}", response_model=RunRead)
def get_run(run_id: str, session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator", "reviewer", "viewer"))) -> RunRead:
    run = session.get(OrchestrationRun, UUID(run_id))
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    return build_run_read(session, run)


@router.post("/runs/{run_id}/execute", response_model=RunEnqueueResponse, status_code=status.HTTP_202_ACCEPTED)
def execute_run(run_id: str, session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator"))) -> RunEnqueueResponse:
    svc = OrchestratorService(session)
    run = svc.enqueue_run(UUID(run_id))
    return RunEnqueueResponse(run_id=run.id, status=run.status, queue_status=run.queue_status, message="Run execution requested")


@router.post("/runs/{run_id}/cancel", response_model=RunRead)
def cancel_run(run_id: str, session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator"))) -> RunRead:
    svc = OrchestratorService(session)
    run = svc.cancel_run(UUID(run_id))
    return build_run_read(session, run)


@router.post("/runs/{run_id}/resume", response_model=RunEnqueueResponse, status_code=status.HTTP_202_ACCEPTED)
def resume_run(run_id: str, session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator"))) -> RunEnqueueResponse:
    svc = OrchestratorService(session)
    run = svc.resume_run(UUID(run_id))
    return RunEnqueueResponse(run_id=run.id, status=run.status, queue_status=run.queue_status, message="Run resume requested")


@router.post("/runs/{run_id}/retry", response_model=RunEnqueueResponse, status_code=status.HTTP_202_ACCEPTED)
def retry_run(run_id: str, session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator"))) -> RunEnqueueResponse:
    svc = OrchestratorService(session)
    run = svc.resume_run(UUID(run_id))
    return RunEnqueueResponse(run_id=run.id, status=run.status, queue_status=run.queue_status, message="Run retry requested")


@router.post("/runs/{run_id}/steps/{step_id}/retry", response_model=RunEnqueueResponse, status_code=status.HTTP_202_ACCEPTED)
def retry_step(run_id: str, step_id: str, body: StepRetryRequest, session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator"))) -> RunEnqueueResponse:
    svc = OrchestratorService(session)
    run = svc.retry_step(UUID(run_id), UUID(step_id), body.mode)
    return RunEnqueueResponse(run_id=run.id, status=run.status, queue_status=run.queue_status, message="Step retry requested")


@router.get("/runs/{run_id}/events", response_model=list[EventRead])
def list_events(run_id: str, session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator", "reviewer", "viewer"))) -> list[OrchestrationEvent]:
    run_uuid = UUID(run_id)
    return session.exec(
        select(OrchestrationEvent)
        .where(OrchestrationEvent.run_id == run_uuid)
        .order_by(OrchestrationEvent.created_at.asc())
    ).all()


@router.delete("/runs/{run_id}", response_model=MessageResponse)
def delete_run(run_id: str, session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin"))) -> MessageResponse:
    run = session.get(OrchestrationRun, UUID(run_id))
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    session.delete(run)
    session.commit()
    return MessageResponse(message="Run deleted")
