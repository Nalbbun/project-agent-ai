from __future__ import annotations

from datetime import datetime
from uuid import UUID

from fastapi import HTTPException
from sqlmodel import Session, select

from app.core.config import get_settings
from app.models.approval import RunApproval
from app.models.run import OrchestrationRun, OrchestrationStep

settings = get_settings()


class ApprovalService:
    def __init__(self, session: Session):
        self.session = session

    def get_or_create_pending(self, run: OrchestrationRun, step: OrchestrationStep, requested_by_user_id=None) -> RunApproval:
        approval = self.session.exec(
            select(RunApproval)
            .where(RunApproval.run_id == run.id)
            .where(RunApproval.step_id == step.id)
            .order_by(RunApproval.created_at.desc())
        ).first()
        if approval and approval.status in {"approved", "pending"}:
            return approval
        approval = RunApproval(
            run_id=run.id,
            step_id=step.id,
            phase=step.phase,
            status="pending",
            required_role=settings.approval_default_role,
            requested_by_user_id=requested_by_user_id,
        )
        self.session.add(approval)
        self.session.commit()
        self.session.refresh(approval)
        return approval

    def list_for_run(self, run_id: UUID) -> list[RunApproval]:
        return self.session.exec(select(RunApproval).where(RunApproval.run_id == run_id).order_by(RunApproval.created_at.asc())).all()

    def decide(self, run_id: UUID, approval_id: UUID, user_id: UUID, decision: str, note: str | None = None) -> RunApproval:
        approval = self.session.get(RunApproval, approval_id)
        run = self.session.get(OrchestrationRun, run_id)
        if not approval or not run or approval.run_id != run.id:
            raise HTTPException(status_code=404, detail="Approval not found")
        if approval.status != "pending":
            raise HTTPException(status_code=409, detail="Approval already decided")
        approval.status = decision
        approval.decided_by_user_id = user_id
        approval.decision_at = datetime.utcnow()
        approval.note = note
        self.session.add(approval)
        step = self.session.get(OrchestrationStep, approval.step_id) if approval.step_id else None
        if decision == "approved":
            if step and step.status == "waiting_approval":
                step.status = "pending"
                step.error_message = None
                self.session.add(step)
            if settings.approval_auto_resume:
                run.queue_status = "resuming"
                run.status = "queued"
                run.waiting_reason = None
                run.next_attempt_at = datetime.utcnow()
                run.updated_at = datetime.utcnow()
                self.session.add(run)
        else:
            if step:
                step.status = "blocked"
                step.error_message = note or "Approval rejected"
                self.session.add(step)
            run.queue_status = "approval_rejected"
            run.status = "blocked"
            run.waiting_reason = "approval_rejected"
            run.last_error = note or "Approval rejected"
            run.updated_at = datetime.utcnow()
            self.session.add(run)
        self.session.commit()
        self.session.refresh(approval)
        return approval
