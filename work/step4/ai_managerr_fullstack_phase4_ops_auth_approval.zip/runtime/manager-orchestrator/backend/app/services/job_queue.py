from __future__ import annotations

from datetime import datetime
from uuid import UUID

from fastapi import HTTPException
from sqlmodel import Session, select

from app.models.run import OrchestrationRun


class JobQueueService:
    def __init__(self, session: Session):
        self.session = session

    def enqueue_run(self, run_id: UUID) -> OrchestrationRun:
        run = self.session.get(OrchestrationRun, run_id)
        if not run:
            raise HTTPException(status_code=404, detail="Run not found")
        if run.queue_status == "running":
            return run
        run.queue_status = "queued"
        run.status = "queued"
        run.last_error = None
        run.waiting_reason = None
        run.next_attempt_at = datetime.utcnow()
        run.updated_at = datetime.utcnow()
        self.session.add(run)
        self.session.commit()
        self.session.refresh(run)
        return run

    def cancel_run(self, run_id: UUID) -> OrchestrationRun:
        run = self.session.get(OrchestrationRun, run_id)
        if not run:
            raise HTTPException(status_code=404, detail="Run not found")
        run.queue_status = "cancelled"
        run.status = "cancelled"
        run.updated_at = datetime.utcnow()
        self.session.add(run)
        self.session.commit()
        self.session.refresh(run)
        return run

    def next_pending_run(self) -> OrchestrationRun | None:
        now = datetime.utcnow()
        stmt = (
            select(OrchestrationRun)
            .where(OrchestrationRun.queue_status.in_(["queued", "resuming", "retry_scheduled"]))
            .where((OrchestrationRun.next_attempt_at.is_(None)) | (OrchestrationRun.next_attempt_at <= now))
            .order_by(OrchestrationRun.created_at.asc())
        )
        return self.session.exec(stmt).first()
