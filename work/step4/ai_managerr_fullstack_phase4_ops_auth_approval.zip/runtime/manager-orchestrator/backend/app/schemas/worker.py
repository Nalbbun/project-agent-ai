from __future__ import annotations

from datetime import datetime
from typing import Any, Optional
from uuid import UUID

from pydantic import BaseModel


class WorkerRead(BaseModel):
    id: UUID
    worker_id: str
    hostname: str
    pid: int
    status: str
    current_run_id: Optional[UUID] = None
    current_step_phase: Optional[str] = None
    last_seen_at: datetime
    details: Optional[dict[str, Any]] = None
    created_at: datetime
