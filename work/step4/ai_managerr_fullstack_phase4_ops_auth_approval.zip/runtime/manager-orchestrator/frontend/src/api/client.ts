import type { Approval, Artifact, LoginResponse, RunEnqueueResponse, User, WorkerStatus } from '../types';

const API_BASE = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8080/api';
const TOKEN_KEY = 'manager_orchestrator_token';
const USER_KEY = 'manager_orchestrator_user';

export function getToken() {
  return localStorage.getItem(TOKEN_KEY) ?? '';
}

export function setAuth(data: LoginResponse) {
  localStorage.setItem(TOKEN_KEY, data.access_token);
  localStorage.setItem(USER_KEY, JSON.stringify(data.user));
}

export function clearAuth() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
}

export function getStoredUser(): User | null {
  const raw = localStorage.getItem(USER_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as User;
  } catch {
    return null;
  }
}

async function request<T>(url: string, init?: RequestInit): Promise<T> {
  const token = getToken();
  const headers: Record<string, string> = { 'Content-Type': 'application/json', ...(init?.headers as Record<string, string> ?? {}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  const response = await fetch(`${API_BASE}${url}`, { ...init, headers });
  if (!response.ok) {
    const text = await response.text();
    throw new Error(text || 'Request failed');
  }
  return response.json() as Promise<T>;
}

export const api = {
  login: (body: { username: string; password: string }) => request<LoginResponse>('/auth/login', { method: 'POST', body: JSON.stringify(body) }),
  me: () => request<User>('/auth/me'),
  logout: () => request('/auth/logout', { method: 'POST' }),
  dashboard: () => request('/dashboard'),
  agents: () => request('/agents'),
  workers: () => request<WorkerStatus[]>('/workers'),
  projects: () => request('/projects'),
  createProject: (body: { name: string; description?: string }) => request('/projects', { method: 'POST', body: JSON.stringify(body) }),
  projectKnowledge: (projectId: string) => request(`/projects/${projectId}/knowledge`),
  createProjectKnowledge: (projectId: string, body: { title: string; content: string; source_type?: string; tags?: string[]; summary?: string }) => request(`/projects/${projectId}/knowledge`, { method: 'POST', body: JSON.stringify(body) }),
  runs: () => request('/runs'),
  run: (id: string) => request(`/runs/${id}`),
  approvals: (runId: string) => request<Approval[]>(`/runs/${runId}/approvals`),
  approve: (runId: string, approvalId: string, note = '') => request<Approval>(`/runs/${runId}/approvals/${approvalId}/approve`, { method: 'POST', body: JSON.stringify({ note }) }),
  reject: (runId: string, approvalId: string, note = '') => request<Approval>(`/runs/${runId}/approvals/${approvalId}/reject`, { method: 'POST', body: JSON.stringify({ note }) }),
  createRun: (body: { project_id?: string | null; title: string; user_request: string; execution_mode?: string }) => request('/runs', { method: 'POST', body: JSON.stringify(body) }),
  executeRun: (id: string) => request<RunEnqueueResponse>(`/runs/${id}/execute`, { method: 'POST' }),
  retryRun: (id: string) => request<RunEnqueueResponse>(`/runs/${id}/retry`, { method: 'POST' }),
  cancelRun: (id: string) => request(`/runs/${id}/cancel`, { method: 'POST' }),
  resumeRun: (id: string) => request<RunEnqueueResponse>(`/runs/${id}/resume`, { method: 'POST' }),
  retryStep: (runId: string, stepId: string, mode = 'from-step') => request<RunEnqueueResponse>(`/runs/${runId}/steps/${stepId}/retry`, { method: 'POST', body: JSON.stringify({ mode }) }),
  artifacts: (runId: string) => request<Artifact[]>(`/runs/${runId}/artifacts`),
};
