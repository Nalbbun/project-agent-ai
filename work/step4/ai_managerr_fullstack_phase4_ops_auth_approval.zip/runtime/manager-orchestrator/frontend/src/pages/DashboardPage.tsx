import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client';
import StatCard from '../components/StatCard';
import type { DashboardSummary } from '../types';

export default function DashboardPage() {
  const [summary, setSummary] = useState<DashboardSummary | null>(null);

  useEffect(() => {
    api.dashboard().then(setSummary).catch(console.error);
  }, []);

  if (!summary) return <div>Loading...</div>;

  return (
    <div className="page">
      <header className="page-header">
        <h2>Dashboard</h2>
        <p className="muted">멀티 에이전트 운영 현황과 최근 실행</p>
      </header>
      <section className="stat-grid">
        <StatCard title="Projects" value={summary.project_count} />
        <StatCard title="Agents" value={summary.agent_count} />
        <StatCard title="Runs" value={summary.run_count} />
        <StatCard title="Running" value={summary.running_count} />
        <StatCard title="Completed" value={summary.completed_count} />
        <StatCard title="Workers" value={summary.worker_count} />
        <StatCard title="Active Workers" value={summary.active_worker_count} />
      </section>
      <section className="card">
        <h3>Latest Runs</h3>
        <div className="list-grid">
          {summary.latest_runs.map((run) => (
            <Link key={run.id} to={`/runs/${run.id}`} className="list-item">
              <strong>{run.title}</strong>
              <span className="muted">status: {run.status}</span>
              <span className="muted">queue: {run.queue_status}</span>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
