import { useEffect, useState } from 'react';
import { api } from '../api/client';
import type { WorkerStatus } from '../types';

export default function WorkersPage() {
  const [workers, setWorkers] = useState<WorkerStatus[]>([]);

  useEffect(() => {
    api.workers().then(setWorkers).catch(console.error);
  }, []);

  return (
    <div className="page">
      <header className="page-header">
        <h2>Workers</h2>
        <p className="muted">worker heartbeat / current run / last seen</p>
      </header>
      <div className="list-grid">
        {workers.map((worker) => (
          <div key={worker.id} className="card">
            <strong>{worker.worker_id}</strong>
            <div className="muted">status: {worker.status}</div>
            <div className="muted">host: {worker.hostname} / pid: {worker.pid}</div>
            <div className="muted">run: {worker.current_run_id ?? '-'}</div>
            <div className="muted">phase: {worker.current_step_phase ?? '-'}</div>
            <div className="muted">last seen: {new Date(worker.last_seen_at).toLocaleString()}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
