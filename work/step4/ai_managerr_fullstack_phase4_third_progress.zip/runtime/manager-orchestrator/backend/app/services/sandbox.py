from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Any

from app.core.config import get_settings

settings = get_settings()


class SandboxExecutor:
    """Best-effort isolated command runner.

    Modes:
    - local: run with stripped environment, dedicated HOME/TMP, workspace cwd.
    - docker: run inside a disposable container when docker is available.

    This is not a hardened security boundary by itself, but it gives the runtime
    an explicit sandbox execution layer and allows production deployments to
    switch to containerized execution without changing orchestrator logic.
    """

    def __init__(self, timeout_seconds: int | None = None):
        self.timeout_seconds = timeout_seconds or settings.tool_command_timeout_seconds
        self.mode = getattr(settings, "runner_sandbox_mode", "local")
        self.image = getattr(settings, "runner_sandbox_docker_image", "python:3.12-slim")
        self.network_enabled = getattr(settings, "runner_sandbox_network_enabled", False)

    def run(self, command: str, workspace: Path) -> dict[str, Any]:
        if self.mode == "docker" and shutil.which("docker"):
            return self._run_docker(command, workspace)
        return self._run_local(command, workspace)

    def _run_local(self, command: str, workspace: Path) -> dict[str, Any]:
        sandbox_home = workspace / ".sandbox_home"
        sandbox_tmp = workspace / ".sandbox_tmp"
        sandbox_home.mkdir(parents=True, exist_ok=True)
        sandbox_tmp.mkdir(parents=True, exist_ok=True)

        allow_env = {
            "PATH": os.environ.get("PATH", ""),
            "HOME": str(sandbox_home),
            "TMPDIR": str(sandbox_tmp),
            "TEMP": str(sandbox_tmp),
            "TMP": str(sandbox_tmp),
            "PYTHONUNBUFFERED": "1",
            "CI": "1",
            "RUNNER_SANDBOX_MODE": "local",
        }
        return self._execute(command, workspace, allow_env, sandbox_mode="local")

    def _run_docker(self, command: str, workspace: Path) -> dict[str, Any]:
        docker_cmd = [
            "docker", "run", "--rm",
            "-v", f"{workspace.resolve()}:/workspace",
            "-w", "/workspace",
        ]
        if not self.network_enabled:
            docker_cmd += ["--network", "none"]
        docker_cmd += [self.image, "sh", "-lc", command]
        started = time.perf_counter()
        try:
            proc = subprocess.run(
                docker_cmd,
                capture_output=True,
                text=True,
                timeout=self.timeout_seconds,
            )
            return {
                "command": command,
                "sandbox_mode": "docker",
                "sandbox_image": self.image,
                "network_enabled": self.network_enabled,
                "exit_code": proc.returncode,
                "stdout": (proc.stdout or "")[-4000:],
                "stderr": (proc.stderr or "")[-4000:],
                "duration_ms": int((time.perf_counter() - started) * 1000),
                "status": "pass" if proc.returncode == 0 else "fail",
            }
        except subprocess.TimeoutExpired as exc:
            stdout = (exc.stdout.decode() if isinstance(exc.stdout, bytes) else (exc.stdout or ""))
            stderr = (exc.stderr.decode() if isinstance(exc.stderr, bytes) else (exc.stderr or ""))
            return {
                "command": command,
                "sandbox_mode": "docker",
                "sandbox_image": self.image,
                "network_enabled": self.network_enabled,
                "exit_code": None,
                "stdout": stdout[-4000:],
                "stderr": (stderr + f"\nTimed out after {self.timeout_seconds}s")[-4000:],
                "duration_ms": int((time.perf_counter() - started) * 1000),
                "status": "fail",
            }

    def _execute(self, command: str, workspace: Path, env: dict[str, str], sandbox_mode: str) -> dict[str, Any]:
        started = time.perf_counter()
        try:
            proc = subprocess.run(
                command,
                cwd=workspace,
                shell=True,
                capture_output=True,
                text=True,
                timeout=self.timeout_seconds,
                env=env,
            )
            return {
                "command": command,
                "sandbox_mode": sandbox_mode,
                "network_enabled": False,
                "exit_code": proc.returncode,
                "stdout": (proc.stdout or "")[-4000:],
                "stderr": (proc.stderr or "")[-4000:],
                "duration_ms": int((time.perf_counter() - started) * 1000),
                "status": "pass" if proc.returncode == 0 else "fail",
            }
        except subprocess.TimeoutExpired as exc:
            stdout = (exc.stdout.decode() if isinstance(exc.stdout, bytes) else (exc.stdout or ""))
            stderr = (exc.stderr.decode() if isinstance(exc.stderr, bytes) else (exc.stderr or ""))
            return {
                "command": command,
                "sandbox_mode": sandbox_mode,
                "network_enabled": False,
                "exit_code": None,
                "stdout": stdout[-4000:],
                "stderr": (stderr + f"\nTimed out after {self.timeout_seconds}s")[-4000:],
                "duration_ms": int((time.perf_counter() - started) * 1000),
                "status": "fail",
            }
