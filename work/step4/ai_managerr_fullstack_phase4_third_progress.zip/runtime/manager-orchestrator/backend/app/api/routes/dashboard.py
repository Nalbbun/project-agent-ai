import asyncio
import json

from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from sqlmodel import Session, select

from app.api.deps import get_accessible_project_ids, get_db_session, require_roles
from app.models.agent import AgentCatalog
from app.models.project import Project
from app.models.run import OrchestrationRun
from app.models.user_account import UserAccount
from app.schemas.run import DashboardSummary
from app.services.run_reader import build_run_read
from app.services.worker_service import WorkerService
from app.core.config import get_settings

router = APIRouter(tags=["dashboard"])
settings = get_settings()


def _build_summary(session: Session, user: UserAccount) -> DashboardSummary:
    stmt = select(OrchestrationRun).order_by(OrchestrationRun.created_at.desc())
    if user.role != "admin":
        allowed = get_accessible_project_ids(session, user, "viewer")
        runs = [run for run in session.exec(stmt).all() if (run.project_id is None or run.project_id in allowed)]
        projects = [project for project in session.exec(select(Project)).all() if project.id in allowed]
    else:
        runs = session.exec(stmt).all()
        projects = session.exec(select(Project)).all()
    latest_runs = [build_run_read(session, run) for run in runs[:5]]
    worker_summary = WorkerService(session).summarize()
    return DashboardSummary(
        project_count=len(projects),
        agent_count=len(session.exec(select(AgentCatalog)).all()),
        run_count=len(runs),
        running_count=sum(1 for r in runs if r.queue_status in {"queued", "resuming", "running", "retry_scheduled", "waiting_approval"}),
        completed_count=sum(1 for r in runs if r.status == "completed"),
        blocked_count=sum(1 for r in runs if r.status in {"blocked", "failed"}),
        dead_lettered_count=sum(1 for r in runs if r.queue_status == "dead_lettered"),
        waiting_approval_count=sum(1 for r in runs if r.queue_status == "waiting_approval"),
        worker_count=worker_summary["worker_count"],
        active_worker_count=worker_summary["active_worker_count"],
        latest_runs=latest_runs,
    )


@router.get("/dashboard", response_model=DashboardSummary)
def get_dashboard(session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator", "reviewer", "viewer"))) -> DashboardSummary:
    return _build_summary(session, user)


@router.get("/dashboard/stream")
async def stream_dashboard(session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator", "reviewer", "viewer"))):
    async def event_generator():
        last_payload = None
        while True:
            with Session(session.bind) as stream_session:
                payload = _build_summary(stream_session, user).model_dump(mode="json")
                dumped = json.dumps(payload, ensure_ascii=False, sort_keys=True)
                if dumped != last_payload:
                    yield f"event: snapshot\ndata: {dumped}\n\n"
                    last_payload = dumped
            await asyncio.sleep(settings.event_stream_poll_interval_seconds)

    return StreamingResponse(event_generator(), media_type="text/event-stream")
