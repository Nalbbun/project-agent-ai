import { FormEvent, useEffect, useState } from 'react';
import { api } from '../api/client';
import type { Project, ProjectKnowledge, ProjectMembership, User } from '../types';

export default function ProjectsPage() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<string>('');
  const [knowledge, setKnowledge] = useState<ProjectKnowledge[]>([]);
  const [memberships, setMemberships] = useState<ProjectMembership[]>([]);
  const [form, setForm] = useState({ name: '', description: '' });
  const [knowledgeForm, setKnowledgeForm] = useState({ title: '', content: '' });
  const [membershipForm, setMembershipForm] = useState({ user_id: '', access_role: 'viewer' });

  const loadProjects = async () => {
    const rows = await api.projects();
    setProjects(rows as Project[]);
    if (!selectedProjectId && rows[0]?.id) setSelectedProjectId(rows[0].id);
  };

  useEffect(() => { loadProjects().catch(console.error); api.users().then(setUsers).catch(() => setUsers([])); }, []);
  useEffect(() => {
    if (!selectedProjectId) return;
    api.projectKnowledge(selectedProjectId).then((rows) => setKnowledge(rows as ProjectKnowledge[])).catch(console.error);
    api.projectMemberships(selectedProjectId).then(setMemberships).catch(console.error);
  }, [selectedProjectId]);

  const createProject = async (e: FormEvent) => {
    e.preventDefault();
    await api.createProject(form);
    setForm({ name: '', description: '' });
    await loadProjects();
  };

  const createKnowledge = async (e: FormEvent) => {
    e.preventDefault();
    if (!selectedProjectId) return;
    await api.createProjectKnowledge(selectedProjectId, knowledgeForm);
    setKnowledgeForm({ title: '', content: '' });
    const rows = await api.projectKnowledge(selectedProjectId);
    setKnowledge(rows as ProjectKnowledge[]);
  };

  const addMembership = async (e: FormEvent) => {
    e.preventDefault();
    if (!selectedProjectId || !membershipForm.user_id) return;
    await api.createProjectMembership(selectedProjectId, membershipForm);
    setMembershipForm({ user_id: '', access_role: 'viewer' });
    setMemberships(await api.projectMemberships(selectedProjectId));
  };

  return (
    <div className="page two-column">
      <section className="card form-card">
        <h3>Create Project</h3>
        <form onSubmit={createProject}>
          <label>Name<input value={form.name} onChange={(e) => setForm((prev) => ({ ...prev, name: e.target.value }))} /></label>
          <label>Description<textarea rows={4} value={form.description} onChange={(e) => setForm((prev) => ({ ...prev, description: e.target.value }))} /></label>
          <button type="submit">프로젝트 생성</button>
        </form>
        <h3 style={{ marginTop: 24 }}>Projects</h3>
        <div className="list-grid">
          {projects.map((project) => (
            <button type="button" key={project.id} className="list-item" onClick={() => setSelectedProjectId(project.id)}>
              <strong>{project.name}</strong>
              <span className="muted">{project.description ?? '-'}</span>
            </button>
          ))}
        </div>
      </section>
      <section className="page">
        <div className="card">
          <h3>Knowledge</h3>
          <form onSubmit={createKnowledge}>
            <label>Title<input value={knowledgeForm.title} onChange={(e) => setKnowledgeForm((prev) => ({ ...prev, title: e.target.value }))} /></label>
            <label>Content<textarea rows={5} value={knowledgeForm.content} onChange={(e) => setKnowledgeForm((prev) => ({ ...prev, content: e.target.value }))} /></label>
            <button type="submit" disabled={!selectedProjectId}>지식 추가</button>
          </form>
          <div className="list-grid" style={{ marginTop: 16 }}>
            {knowledge.map((item) => (
              <div key={item.id} className="list-item">
                <strong>{item.title}</strong>
                <span className="muted">{item.source_type}</span>
                <pre className="artifact-preview">{item.content}</pre>
              </div>
            ))}
          </div>
        </div>
        <div className="card">
          <h3>Memberships</h3>
          <form onSubmit={addMembership}>
            <label>User<select value={membershipForm.user_id} onChange={(e) => setMembershipForm((prev) => ({ ...prev, user_id: e.target.value }))}>
              <option value="">선택</option>
              {users.map((user) => <option key={user.id} value={user.id}>{user.display_name} ({user.role})</option>)}
            </select></label>
            <label>Access Role<select value={membershipForm.access_role} onChange={(e) => setMembershipForm((prev) => ({ ...prev, access_role: e.target.value }))}>
              <option value="viewer">viewer</option>
              <option value="reviewer">reviewer</option>
              <option value="editor">editor</option>
              <option value="owner">owner</option>
            </select></label>
            <button type="submit" disabled={!selectedProjectId}>멤버 추가</button>
          </form>
          <div className="list-grid" style={{ marginTop: 16 }}>
            {memberships.map((item) => (
              <div key={item.id} className="list-item">
                <strong>{users.find((user) => user.id === item.user_id)?.display_name ?? item.user_id}</strong>
                <span className="muted">role: {item.access_role}</span>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
