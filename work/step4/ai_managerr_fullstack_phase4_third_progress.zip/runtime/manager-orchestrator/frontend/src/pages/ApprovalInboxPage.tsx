import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { api, getStoredUser } from '../api/client';
import type { ApprovalInboxItem } from '../types';

export default function ApprovalInboxPage() {
  const [items, setItems] = useState<ApprovalInboxItem[]>([]);
  const [busyId, setBusyId] = useState<string>('');
  const user = getStoredUser();

  const load = async () => {
    const rows = await api.approvalInbox();
    setItems(rows);
  };

  useEffect(() => { load().catch(console.error); }, []);

  const actionable = useMemo(() => items.filter((item) => item.actionable), [items]);
  const queued = useMemo(() => items.filter((item) => !item.actionable), [items]);

  const decide = async (item: ApprovalInboxItem, decision: 'approve' | 'reject') => {
    setBusyId(item.id);
    try {
      if (decision === 'approve') await api.approve(item.run_id, item.id, `Approved by ${user?.display_name ?? 'reviewer'}`);
      else await api.reject(item.run_id, item.id, `Rejected by ${user?.display_name ?? 'reviewer'}`);
      await load();
    } finally {
      setBusyId('');
    }
  };

  const renderCard = (item: ApprovalInboxItem) => (
    <div key={item.id} className="list-item">
      <strong>{item.run_title}</strong>
      <span className="muted">project: {item.project_name ?? '-'}</span>
      <span className="muted">phase: {item.phase} / stage {item.stage_index}/{item.stage_total}</span>
      <span className="muted">required: {item.required_role} / status: {item.status}</span>
      <span className="muted">waiting: {item.waiting_reason ?? '-'}</span>
      <div className="actions">
        <Link to={`/runs/${item.run_id}`} className="secondary">Run 보기</Link>
        {item.actionable && (
          <>
            <button className="secondary" disabled={busyId === item.id} onClick={() => decide(item, 'approve')}>Approve</button>
            <button className="secondary" disabled={busyId === item.id} onClick={() => decide(item, 'reject')}>Reject</button>
          </>
        )}
      </div>
    </div>
  );

  return (
    <div className="page">
      <header className="page-header split">
        <div>
          <h2>Approval Inbox</h2>
          <p className="muted">내 역할에 해당하는 승인 대기함과 다음 승인 대기열</p>
        </div>
        <div className="actions"><button className="secondary" onClick={() => load().catch(console.error)}>새로고침</button></div>
      </header>
      <section className="card">
        <h3>Actionable</h3>
        <div className="list-grid">{actionable.length ? actionable.map(renderCard) : <div className="muted">대기 중인 승인 없음</div>}</div>
      </section>
      <section className="card">
        <h3>Queued / Later Stages</h3>
        <div className="list-grid">{queued.length ? queued.map(renderCard) : <div className="muted">후속 승인 대기 없음</div>}</div>
      </section>
    </div>
  );
}
