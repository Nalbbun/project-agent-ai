from fastapi import APIRouter, Depends
from sqlmodel import Session

from app.api.deps import get_db_session, require_roles
from app.models.user_account import UserAccount
from app.schemas.worker import WorkerMaintenanceResult, WorkerRead
from app.services.job_queue import JobQueueService
from app.services.worker_service import WorkerService

router = APIRouter(tags=["workers"])


@router.get("/workers", response_model=list[WorkerRead])
def list_workers(session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator", "reviewer", "viewer"))) -> list[WorkerRead]:
    rows = WorkerService(session).list_workers()
    return [WorkerRead.model_validate(row, from_attributes=True) for row in rows]


@router.post("/workers/maintenance", response_model=WorkerMaintenanceResult)
def maintain_workers(session: Session = Depends(get_db_session), user: UserAccount = Depends(require_roles("admin", "operator"))) -> WorkerMaintenanceResult:
    queue = JobQueueService(session)
    reclaimed = queue.reclaim_stale_runs()
    dead_lettered = queue.dead_letter_exhausted_runs()
    return WorkerMaintenanceResult(reclaimed_runs=reclaimed, dead_lettered_runs=dead_lettered)
