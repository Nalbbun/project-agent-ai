from __future__ import annotations

from datetime import datetime
from typing import Optional
from uuid import UUID

from pydantic import BaseModel, Field


class ApprovalDecisionRequest(BaseModel):
    note: Optional[str] = Field(default=None, max_length=500)


class ApprovalRead(BaseModel):
    id: UUID
    run_id: UUID
    step_id: Optional[UUID] = None
    phase: str
    status: str
    required_role: str
    stage_index: int = 1
    stage_total: int = 1
    requested_by_user_id: Optional[UUID] = None
    decided_by_user_id: Optional[UUID] = None
    note: Optional[str] = None
    decision_at: Optional[datetime] = None
    created_at: datetime
