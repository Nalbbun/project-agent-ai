import { useEffect, useState } from 'react';
import { api } from '../api/client';
import type { WorkerMaintenanceResult, WorkerStatus } from '../types';

export default function WorkersPage() {
  const [workers, setWorkers] = useState<WorkerStatus[]>([]);
  const [maintenance, setMaintenance] = useState<WorkerMaintenanceResult | null>(null);
  const [busy, setBusy] = useState(false);

  const load = () => api.workers().then(setWorkers).catch(console.error);
  useEffect(() => { load(); }, []);

  const runMaintenance = async () => {
    setBusy(true);
    try {
      const result = await api.maintainWorkers();
      setMaintenance(result);
      await load();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="page">
      <header className="page-header split">
        <div>
          <h2>Workers</h2>
          <p className="muted">worker heartbeat / stale run reclaim / dead-letter maintenance</p>
        </div>
        <div className="actions">
          <button className="secondary" onClick={runMaintenance} disabled={busy}>{busy ? '처리 중...' : 'Maintenance 실행'}</button>
        </div>
      </header>
      {maintenance && <div className="card muted">reclaimed_runs: {maintenance.reclaimed_runs} / dead_lettered_runs: {maintenance.dead_lettered_runs}</div>}
      <div className="list-grid">
        {workers.map((worker) => (
          <div key={worker.id} className="card">
            <strong>{worker.worker_id}</strong>
            <div className="muted">status: {worker.status}</div>
            <div className="muted">host: {worker.hostname} / pid: {worker.pid}</div>
            <div className="muted">run: {worker.current_run_id ?? '-'}</div>
            <div className="muted">phase: {worker.current_step_phase ?? '-'}</div>
            <div className="muted">last seen: {new Date(worker.last_seen_at).toLocaleString()}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
