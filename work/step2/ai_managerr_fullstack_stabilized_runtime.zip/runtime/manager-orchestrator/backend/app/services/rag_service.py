from __future__ import annotations

from typing import Any
from uuid import UUID

from sqlmodel import Session, select

from app.models.artifact import Artifact


class RagService:
    def __init__(self, session: Session):
        self.session = session

    def retrieve(self, project_id: UUID | None, role: str, query: str, top_k: int = 5) -> list[dict[str, Any]]:
        del project_id, query
        artifacts = self.session.exec(
            select(Artifact)
            .where(Artifact.artifact_type == "step-output")
            .order_by(Artifact.created_at.desc())
        ).all()
        results: list[dict[str, Any]] = []
        for artifact in artifacts[:top_k]:
            results.append(
                {
                    "source": artifact.name,
                    "role": role,
                    "summary": artifact.summary or artifact.name,
                    "content": artifact.content,
                }
            )
        return results
