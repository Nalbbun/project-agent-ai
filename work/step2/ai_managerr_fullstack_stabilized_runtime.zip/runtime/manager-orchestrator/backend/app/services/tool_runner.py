from __future__ import annotations

from typing import Any


class ToolRunner:
    def run_build(self, step_phase: str, payload: dict[str, Any]) -> dict[str, Any]:
        return {"tool": "build", "phase": step_phase, "status": "stub", "detail": "build runner not connected yet", "payload_keys": list(payload.keys())}

    def run_test(self, step_phase: str, payload: dict[str, Any]) -> dict[str, Any]:
        return {"tool": "test", "phase": step_phase, "status": "stub", "detail": "test runner not connected yet", "payload_keys": list(payload.keys())}

    def run_lint(self, step_phase: str, payload: dict[str, Any]) -> dict[str, Any]:
        return {"tool": "lint", "phase": step_phase, "status": "stub", "detail": "lint runner not connected yet", "payload_keys": list(payload.keys())}

    def run_scan(self, step_phase: str, payload: dict[str, Any]) -> dict[str, Any]:
        return {"tool": "scan", "phase": step_phase, "status": "stub", "detail": "security runner not connected yet", "payload_keys": list(payload.keys())}
