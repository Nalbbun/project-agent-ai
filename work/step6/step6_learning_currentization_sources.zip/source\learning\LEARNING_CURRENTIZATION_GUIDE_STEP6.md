# Learning Currentization Guide - Step 6

작성일: 2026-04-28

## 1. 현재 상태 요약

`source/learning`은 8개 agent role(`manager`, `pm`, `architect`, `dev-fe`, `dev-be`, `dev-db`, `qa`, `secops`) 기준의 schema, sample JSONL, reward skeleton, SFT/GRPO training script, vLLM/Ollama serving 예시를 갖추고 있다.

현행 runtime은 Step 5 기준으로 다음 운영 기능이 추가되어 있다.

- Router 강제 경유 및 role routing
- Queue/Worker, retry/backoff, dead-letter replay
- Approval, RBAC, project membership
- Artifact/Event/Audit 및 replay diff
- RAG, project knowledge, reindex
- Docker runner sandbox
- Tool runner build/test/lint/type/scan report

따라서 learning 현행화의 핵심은 새 role을 추가하는 것이 아니라, 기존 8개 role dataset과 reward가 runtime의 운영 산출물을 학습 신호로 받아들이도록 확장하는 것이다.

## 2. 검증 결과

샘플 데이터 검증:

```text
all_valid=True
files=16 passed=1975 failed=0
pm: valid=True passed=225 failed=0
architect: valid=True passed=400 failed=0
dev-fe: valid=True passed=225 failed=0
dev-be: valid=True passed=225 failed=0
dev-db: valid=True passed=225 failed=0
qa: valid=True passed=225 failed=0
secops: valid=True passed=225 failed=0
manager: valid=True passed=225 failed=0
```

판단:

- Schema/sample의 기본 품질은 통과 상태다.
- 현행화는 validation failure 수정이 아니라, runtime trace 기반 데이터 확장 작업이다.

## 3. Runtime 대비 gap

### A. Schema gap

현재 schema는 training sample wrapper(`id`, `role`, `input`, `output`, `metadata`)와 role output의 핵심 필드만 강제한다.

현행 runtime의 추가 정보 중 schema에 아직 충분히 반영되지 않은 항목:

- `run_metadata`, `project_id`, `rag_context`
- `artifact` 및 `tool-report`
- `approval` decision context
- `replay_audit` 및 replay mode
- `sandbox` execution result
- router backend/model/fallback metadata

### B. Reward gap

현재 reward는 schema 통과, 필드 존재, 중복/환각 proxy 중심이다.

현행 runtime에 맞춰 추가해야 할 reward:

- RAG citation/usefulness score
- tool-report pass/warn/fail score
- replay recovery quality score
- approval readiness score
- sandbox safety score
- router/model metadata consistency score

### C. Dataset gap

현재 data_examples는 synthetic/sample 중심이다.

현행화 데이터 소스 후보:

- `orchestration_step.output_payload`
- `artifact.content`
- `orchestration_event.payload`
- `run_replay_audit.details`
- `project_knowledge`
- tool runner report artifact

### D. Serving/config gap

역할 및 routing 축은 runtime과 대체로 맞다.

보완할 점:

- learning `serving/k8s/router-configmap.yaml`은 runtime router config의 fallback, timeout, header propagation, unknown role policy까지 반영해야 한다.
- learning `configs/execution.local.yaml`은 현재 Windows/PowerShell 개발 환경보다는 Linux GPU runner 가정이 강하다.
- adapter registry와 runtime `agents.yaml` 사이의 sync check script가 없다.

## 4. 권장 현행화 순서

### Step 6-A. Alignment manifest 고정

`configs/runtime_alignment.step6.yaml`을 기준 파일로 두고 다음 항목을 동기화 기준으로 삼는다.

- role code
- prompt key
- adapter name
- router route
- required output keys
- runtime artifact/reward 확장 대상

### Step 6-B. Runtime trace export 만들기

backend에 직접 학습 기능을 넣기보다, 운영 DB에서 학습 후보를 export하는 script를 별도 작성한다.

권장 출력:

- `data_runtime_exports/{run_id}/{role}.jsonl`
- 각 row는 기존 sample wrapper를 유지하되 `metadata.runtime` 아래에 trace 정보를 넣는다.

예시 metadata:

```json
{
  "metadata": {
    "source": "runtime-export",
    "version": "step6",
    "runtime": {
      "run_id": "...",
      "step_id": "...",
      "project_id": "...",
      "backend_name": "...",
      "target_model": "...",
      "schema_valid": true,
      "tool_report_status": "pass",
      "approval_status": "approved",
      "replay_group": null
    }
  }
}
```

### Step 6-C. Schema v2 설계

기존 v1 schema는 깨지지 않게 유지하고, v2에서 optional runtime metadata를 추가한다.

원칙:

- role output required keys는 runtime `SchemaValidator.REQUIRED_KEYS`와 일치시킨다.
- runtime metadata는 optional로 시작한다.
- tool report, replay audit, approval context는 `metadata.runtime` 아래에 둔다.

### Step 6-D. Reward v2 추가

기존 reward skeleton을 보존하면서 아래 공통 reward를 `rewards/common.py`에 추가한다.

- `runtime_trace_score`
- `tool_report_score`
- `rag_grounding_score`
- `approval_readiness_score`
- `sandbox_safety_score`

role별 reward는 이 공통 reward를 조합한다.

### Step 6-E. Router/config sync check

다음 세 파일을 비교하는 script를 추가한다.

- `source/runtime/manager-orchestrator/config/agents.yaml`
- `source/runtime/work_proxy_deploy/configs/vllm_request_router.local.yaml`
- `source/learning/configs/adapter_registry.local.yaml`

실패 조건:

- active agent인데 adapter registry에 없음
- router route가 없음
- prompt key가 learning role과 매핑되지 않음
- required output key가 runtime validator와 어긋남

### Step 6-F. Small fine-tune pilot

처음부터 전체 role 학습을 돌리지 말고 다음 순서로 간다.

1. `pm`, `architect`, `manager`를 text planning role로 먼저 export/eval
2. `dev-fe`, `dev-be`, `dev-db`는 tool-report reward가 준비된 뒤 진행
3. `qa`, `secops`는 replay/approval/sandbox evidence를 포함한 후 진행

## 5. 다음 작업 체크리스트

- [ ] `scripts/export_runtime_traces.py` 작성
- [ ] `schemas_v2/` 또는 schema `metadata.runtime` 확장안 작성
- [ ] `rewards/common.py`에 runtime reward 함수 추가
- [ ] `scripts/check_runtime_alignment.py` 작성
- [ ] `serving/k8s/router-configmap.yaml`을 runtime router config 수준으로 갱신
- [ ] runtime export sample 20건 생성
- [ ] v1 sample + runtime export sample 통합 검증
- [ ] role별 eval report 생성

## 6. 이번 Step 6 결론

learning은 깨진 상태가 아니라, Step 5 운영 runtime보다 학습 신호가 덜 풍부한 상태다.

가장 먼저 해야 할 작업은 모델 학습 실행이 아니라 다음 3가지다.

1. runtime trace export
2. schema/reward v2
3. runtime-learning alignment check

이 3개가 끝나야 SFT/GRPO가 실제 운영 품질 개선으로 이어질 가능성이 높다.

