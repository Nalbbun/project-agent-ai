from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlmodel import Session, select

from app.api.deps import get_db_session
from app.models.event import OrchestrationEvent
from app.models.run import OrchestrationRun
from app.schemas.common import EventRead, MessageResponse
from app.schemas.run import RunCreate, RunRead
from app.services.orchestrator import OrchestratorService
from app.services.run_reader import build_run_read

router = APIRouter(tags=["runs"])


@router.get("/runs", response_model=list[RunRead])
def list_runs(session: Session = Depends(get_db_session)) -> list[RunRead]:
    runs = session.exec(select(OrchestrationRun).order_by(OrchestrationRun.created_at.desc())).all()
    return [build_run_read(session, run) for run in runs]


@router.post("/runs", response_model=RunRead, status_code=status.HTTP_201_CREATED)
def create_run(payload: RunCreate, session: Session = Depends(get_db_session)) -> RunRead:
    svc = OrchestratorService(session)
    run = svc.create_run(payload)
    return build_run_read(session, run)


@router.get("/runs/{run_id}", response_model=RunRead)
def get_run(run_id: str, session: Session = Depends(get_db_session)) -> RunRead:
    run = session.get(OrchestrationRun, UUID(run_id))
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    return build_run_read(session, run)


@router.post("/runs/{run_id}/execute", response_model=RunRead)
def execute_run(run_id: str, session: Session = Depends(get_db_session)) -> RunRead:
    svc = OrchestratorService(session)
    run = svc.execute_run(UUID(run_id))
    return build_run_read(session, run)


@router.post("/runs/{run_id}/retry", response_model=RunRead)
def retry_run(run_id: str, session: Session = Depends(get_db_session)) -> RunRead:
    svc = OrchestratorService(session)
    run = svc.reset_and_retry(UUID(run_id))
    return build_run_read(session, run)


@router.get("/runs/{run_id}/events", response_model=list[EventRead])
def list_events(run_id: str, session: Session = Depends(get_db_session)) -> list[OrchestrationEvent]:
    run_uuid = UUID(run_id)
    return session.exec(
        select(OrchestrationEvent)
        .where(OrchestrationEvent.run_id == run_uuid)
        .order_by(OrchestrationEvent.created_at.asc())
    ).all()


@router.delete("/runs/{run_id}", response_model=MessageResponse)
def delete_run(run_id: str, session: Session = Depends(get_db_session)) -> MessageResponse:
    run = session.get(OrchestrationRun, UUID(run_id))
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    session.delete(run)
    session.commit()
    return MessageResponse(message="Run deleted")
