from datetime import datetime
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlmodel import Session, select

from app.api.deps import get_db_session
from app.models.project import Project
from app.schemas.project import ProjectCreate, ProjectRead

router = APIRouter(tags=["projects"])


@router.get("/projects", response_model=list[ProjectRead])
def list_projects(session: Session = Depends(get_db_session)) -> list[Project]:
    return session.exec(select(Project).order_by(Project.created_at.desc())).all()


@router.post("/projects", response_model=ProjectRead, status_code=status.HTTP_201_CREATED)
def create_project(payload: ProjectCreate, session: Session = Depends(get_db_session)) -> Project:
    project = Project(name=payload.name, description=payload.description, updated_at=datetime.utcnow())
    session.add(project)
    session.commit()
    session.refresh(project)
    return project


@router.get("/projects/{project_id}", response_model=ProjectRead)
def get_project(project_id: str, session: Session = Depends(get_db_session)) -> Project:
    project = session.get(Project, UUID(project_id))
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return project
