from datetime import datetime
from typing import Any, Optional
from uuid import UUID

from pydantic import BaseModel, Field

from app.schemas.common import EventRead


class RunCreate(BaseModel):
    project_id: Optional[UUID] = None
    title: str = Field(min_length=2, max_length=160)
    user_request: str = Field(min_length=5)


class StepRead(BaseModel):
    id: UUID
    seq: int
    phase: str
    agent_code: str
    status: str
    prompt_text: Optional[str] = None
    output_text: Optional[str] = None
    input_payload: Optional[dict[str, Any]] = None
    output_payload: Optional[dict[str, Any]] = None
    error_message: Optional[str] = None
    started_at: Optional[datetime] = None
    finished_at: Optional[datetime] = None
    created_at: datetime


class RunRead(BaseModel):
    id: UUID
    project_id: Optional[UUID] = None
    title: str
    user_request: str
    status: str
    current_stage: Optional[str] = None
    final_summary: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    steps: list[StepRead] = []
    events: list[EventRead] = []


class DashboardSummary(BaseModel):
    project_count: int
    agent_count: int
    run_count: int
    running_count: int
    completed_count: int
    latest_runs: list[RunRead]
