from sqlmodel import Session, SQLModel, create_engine

from app.core.config import get_settings

settings = get_settings()
connect_args = {}
engine = create_engine(settings.database_url, echo=False, connect_args=connect_args)


def get_session():
    with Session(engine) as session:
        yield session


def create_db_and_tables() -> None:
    from app.models import artifact, event, project, run
    SQLModel.metadata.create_all(engine)
