import uuid
from typing import Optional

from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy import Column
from sqlmodel import Field

from app.models.common import TimestampedModel


class Artifact(TimestampedModel, table=True):
    __tablename__ = "artifact"

    run_id: uuid.UUID = Field(foreign_key="orchestration_run.id")
    step_id: Optional[uuid.UUID] = Field(default=None, foreign_key="orchestration_step.id")
    artifact_type: str = Field(max_length=40)
    name: str = Field(max_length=120)
    content: Optional[dict] = Field(default=None, sa_column=Column(JSONB, nullable=True))
