from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "manager-orchestrator"
    app_env: str = "local"
    simulation_mode: bool = True
    database_url: str = "sqlite:///./local.db"
    cors_origins: str = "http://localhost:5174"
    agent_config_path: str = "./config/agents.yaml"
    default_timeout_seconds: int = 120

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def cors_origins_list(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
