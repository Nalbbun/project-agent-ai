from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import UUID

from fastapi import HTTPException
from sqlmodel import Session, select

from app.models.agent import AgentCatalog
from app.models.artifact import Artifact
from app.models.event import OrchestrationEvent
from app.models.run import OrchestrationRun, OrchestrationStep
from app.schemas.run import RunCreate
from app.services.llm_client import AgentLLMClient
from app.services.prompts import build_prompt

PIPELINE = [
    (1, "manager-plan", "manager"),
    (2, "pm", "pm"),
    (3, "architect", "architect"),
    (4, "dev-fe", "dev-fe"),
    (5, "dev-be", "dev-be"),
    (6, "dev-db", "dev-db"),
    (7, "qa", "qa"),
    (8, "secops", "secops"),
    (9, "manager-merge", "manager"),
]


class OrchestratorService:
    def __init__(self, session: Session):
        self.session = session
        self.client = AgentLLMClient()

    def create_run(self, payload: RunCreate) -> OrchestrationRun:
        run = OrchestrationRun(
            project_id=payload.project_id,
            title=payload.title,
            user_request=payload.user_request,
            status="draft",
            current_stage="created",
        )
        self.session.add(run)
        self.session.commit()
        self.session.refresh(run)

        for seq, phase, agent_code in PIPELINE:
            step = OrchestrationStep(
                run_id=run.id,
                seq=seq,
                phase=phase,
                agent_code=agent_code,
                status="pending",
                input_payload={"phase": phase},
            )
            self.session.add(step)
        self._event(run.id, None, "info", "Run created", {"title": run.title})
        self.session.commit()
        return run

    def execute_run(self, run_id: str | UUID) -> OrchestrationRun:
        run = self.session.get(OrchestrationRun, run_id)
        if not run:
            raise HTTPException(status_code=404, detail="Run not found")

        run.status = "running"
        run.updated_at = datetime.utcnow()
        self.session.add(run)
        self.session.commit()

        steps = self.session.exec(
            select(OrchestrationStep)
            .where(OrchestrationStep.run_id == run.id)
            .order_by(OrchestrationStep.seq.asc())
        ).all()

        for step in steps:
            if step.status == "completed":
                continue
            self._execute_step(run, step)
            if step.status == "failed":
                run.status = "failed"
                run.current_stage = step.phase
                self.session.add(run)
                self.session.commit()
                return run

        run.status = "completed"
        run.current_stage = "done"
        merge_step = next((s for s in steps if s.phase == "manager-merge"), None)
        if merge_step and merge_step.output_payload:
            run.final_summary = merge_step.output_payload.get("final_summary")
        run.updated_at = datetime.utcnow()
        self.session.add(run)
        self._event(run.id, None, "info", "Run completed", {"final_summary": run.final_summary})
        self.session.commit()
        return run

    def reset_and_retry(self, run_id: str | UUID) -> OrchestrationRun:
        run = self.session.get(OrchestrationRun, run_id)
        if not run:
            raise HTTPException(status_code=404, detail="Run not found")
        steps = self.session.exec(select(OrchestrationStep).where(OrchestrationStep.run_id == run.id)).all()
        for step in steps:
            step.status = "pending"
            step.output_payload = None
            step.output_text = None
            step.error_message = None
            step.started_at = None
            step.finished_at = None
            self.session.add(step)
        run.status = "draft"
        run.current_stage = "retry-ready"
        run.final_summary = None
        self.session.add(run)
        self._event(run.id, None, "warning", "Run reset for retry", None)
        self.session.commit()
        return self.execute_run(run.id)

    def _execute_step(self, run: OrchestrationRun, step: OrchestrationStep) -> None:
        agent = self.session.exec(select(AgentCatalog).where(AgentCatalog.code == step.agent_code)).first()
        if not agent:
            step.status = "failed"
            step.error_message = f"Agent not found: {step.agent_code}"
            self.session.add(step)
            self._event(run.id, step.id, "error", step.error_message, None)
            self.session.commit()
            return

        context = self._collect_context(run.id, step.seq)
        prompt_role = agent.prompt_key
        prompt = build_prompt(prompt_role, run.user_request, context)

        step.status = "running"
        step.started_at = datetime.utcnow()
        step.prompt_text = prompt
        step.input_payload = {"user_request": run.user_request, "context": context}
        run.current_stage = step.phase
        self.session.add(run)
        self.session.add(step)
        self._event(run.id, step.id, "info", f"Executing {step.phase}", {"agent": step.agent_code})
        self.session.commit()

        try:
            payload = self.client.invoke(agent, prompt, run.user_request, context)
            step.output_payload = payload
            step.output_text = self._safe_dump(payload)
            step.status = "completed"
            step.finished_at = datetime.utcnow()
            self.session.add(step)
            self._artifact(run.id, step.id, step.phase, f"{step.phase}.json", payload)
            self._event(run.id, step.id, "info", f"Completed {step.phase}", {"agent": step.agent_code})
            self.session.commit()
        except Exception as exc:
            step.status = "failed"
            step.error_message = str(exc)
            step.finished_at = datetime.utcnow()
            self.session.add(step)
            self._event(run.id, step.id, "error", f"Failed {step.phase}", {"error": str(exc)})
            self.session.commit()

    def _collect_context(self, run_id: UUID, upto_seq: int) -> dict[str, Any]:
        prior_steps = self.session.exec(
            select(OrchestrationStep)
            .where(OrchestrationStep.run_id == run_id)
            .where(OrchestrationStep.seq < upto_seq)
            .order_by(OrchestrationStep.seq.asc())
        ).all()
        context: dict[str, Any] = {}
        for step in prior_steps:
            if step.output_payload:
                context[step.phase] = step.output_payload
        return context

    def _artifact(self, run_id: UUID, step_id: UUID, artifact_type: str, name: str, content: dict[str, Any]) -> None:
        artifact = Artifact(run_id=run_id, step_id=step_id, artifact_type=artifact_type, name=name, content=content)
        self.session.add(artifact)

    def _event(self, run_id: UUID, step_id: UUID | None, level: str, message: str, payload: dict[str, Any] | None) -> None:
        event = OrchestrationEvent(run_id=run_id, step_id=step_id, level=level, message=message, payload=payload)
        self.session.add(event)

    @staticmethod
    def _safe_dump(payload: dict[str, Any]) -> str:
        import json

        return json.dumps(payload, ensure_ascii=False, indent=2)
