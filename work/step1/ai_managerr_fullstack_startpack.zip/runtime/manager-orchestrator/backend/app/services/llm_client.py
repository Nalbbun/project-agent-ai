from __future__ import annotations

import json
from typing import Any

import httpx

from app.core.config import get_settings
from app.models.agent import AgentCatalog
from app.services.simulator import simulate

settings = get_settings()


class AgentLLMClient:
    def invoke(self, agent: AgentCatalog, prompt: str, user_request: str, context: dict[str, Any]) -> dict[str, Any]:
        if settings.simulation_mode:
            return simulate(agent.role, user_request, context)

        headers = {"Content-Type": "application/json"}
        payload = {
            "model": agent.model,
            "messages": [
                {"role": "system", "content": f"Use adapter={agent.adapter or ''}. Always respond in JSON."},
                {"role": "user", "content": prompt},
            ],
            "temperature": 0.2,
        }
        with httpx.Client(timeout=settings.default_timeout_seconds) as client:
            response = client.post(f"{agent.endpoint}/chat/completions", headers=headers, json=payload)
            response.raise_for_status()
            data = response.json()
            content = data["choices"][0]["message"]["content"]
            return json.loads(content)
