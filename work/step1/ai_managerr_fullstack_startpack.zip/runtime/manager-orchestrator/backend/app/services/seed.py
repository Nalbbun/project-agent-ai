from __future__ import annotations

from datetime import datetime
from pathlib import Path

import yaml
from sqlmodel import Session, select

from app.core.config import get_settings
from app.db.session import engine
from app.models.agent import AgentCatalog

settings = get_settings()


def seed_agents_from_yaml() -> None:
    config_path = Path(settings.agent_config_path)
    if not config_path.exists():
        return

    config = yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    agents = config.get("agents", [])

    with Session(engine) as session:
        for item in agents:
            existing = session.exec(select(AgentCatalog).where(AgentCatalog.code == item["code"])).first()
            if existing:
                existing.name = item["name"]
                existing.role = item["role"]
                existing.endpoint = item["endpoint"]
                existing.model = item["model"]
                existing.adapter = item.get("adapter")
                existing.prompt_key = item["prompt_key"]
                existing.active = item.get("active", True)
                existing.updated_at = datetime.utcnow()
            else:
                session.add(
                    AgentCatalog(
                        code=item["code"],
                        name=item["name"],
                        role=item["role"],
                        endpoint=item["endpoint"],
                        model=item["model"],
                        adapter=item.get("adapter"),
                        prompt_key=item["prompt_key"],
                        active=item.get("active", True),
                    )
                )
        session.commit()
