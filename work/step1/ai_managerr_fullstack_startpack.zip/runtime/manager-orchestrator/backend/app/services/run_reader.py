from sqlmodel import Session, select

from app.models.event import OrchestrationEvent
from app.models.run import OrchestrationRun, OrchestrationStep
from app.schemas.run import RunRead, StepRead


def build_run_read(session: Session, run: OrchestrationRun) -> RunRead:
    steps = session.exec(
        select(OrchestrationStep)
        .where(OrchestrationStep.run_id == run.id)
        .order_by(OrchestrationStep.seq.asc())
    ).all()
    events = session.exec(
        select(OrchestrationEvent)
        .where(OrchestrationEvent.run_id == run.id)
        .order_by(OrchestrationEvent.created_at.asc())
    ).all()
    return RunRead(
        id=run.id,
        project_id=run.project_id,
        title=run.title,
        user_request=run.user_request,
        status=run.status,
        current_stage=run.current_stage,
        final_summary=run.final_summary,
        created_at=run.created_at,
        updated_at=run.updated_at,
        steps=[StepRead.model_validate(step, from_attributes=True) for step in steps],
        events=events,
    )
