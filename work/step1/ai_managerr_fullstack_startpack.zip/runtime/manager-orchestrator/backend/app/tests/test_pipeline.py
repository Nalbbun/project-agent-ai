from app.services.orchestrator import PIPELINE


def test_pipeline_order():
    phases = [phase for _, phase, _ in PIPELINE]
    assert phases[0] == "manager-plan"
    assert phases[-1] == "manager-merge"
    assert "pm" in phases and "architect" in phases and "qa" in phases and "secops" in phases
