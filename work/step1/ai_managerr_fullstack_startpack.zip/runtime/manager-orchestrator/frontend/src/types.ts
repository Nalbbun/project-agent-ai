export type Project = {
  id: string;
  name: string;
  description?: string | null;
  created_at: string;
  updated_at: string;
};

export type Agent = {
  id: string;
  code: string;
  name: string;
  role: string;
  endpoint: string;
  model: string;
  adapter?: string | null;
  prompt_key: string;
  active: boolean;
  created_at: string;
  updated_at: string;
};

export type RunStep = {
  id: string;
  seq: number;
  phase: string;
  agent_code: string;
  status: string;
  prompt_text?: string | null;
  output_text?: string | null;
  input_payload?: Record<string, unknown> | null;
  output_payload?: Record<string, unknown> | null;
  error_message?: string | null;
  started_at?: string | null;
  finished_at?: string | null;
  created_at: string;
};

export type RunEvent = {
  id: string;
  run_id: string;
  step_id?: string | null;
  level: string;
  message: string;
  payload?: Record<string, unknown> | null;
  created_at: string;
};

export type Run = {
  id: string;
  project_id?: string | null;
  title: string;
  user_request: string;
  status: string;
  current_stage?: string | null;
  final_summary?: string | null;
  created_at: string;
  updated_at: string;
  steps: RunStep[];
  events: RunEvent[];
};

export type DashboardSummary = {
  project_count: number;
  agent_count: number;
  run_count: number;
  running_count: number;
  completed_count: number;
  latest_runs: Run[];
};
