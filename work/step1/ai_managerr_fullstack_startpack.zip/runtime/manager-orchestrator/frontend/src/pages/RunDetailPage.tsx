import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { api } from '../api/client';
import RunTimeline from '../components/RunTimeline';
import type { Run } from '../types';

export default function RunDetailPage() {
  const { runId = '' } = useParams();
  const [run, setRun] = useState<Run | null>(null);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    const data = await api.run(runId);
    setRun(data as Run);
  };

  useEffect(() => {
    load().catch(console.error);
  }, [runId]);

  const execute = async () => {
    setBusy(true);
    try {
      const data = await api.executeRun(runId);
      setRun(data as Run);
    } finally {
      setBusy(false);
    }
  };

  const retry = async () => {
    setBusy(true);
    try {
      const data = await api.retryRun(runId);
      setRun(data as Run);
    } finally {
      setBusy(false);
    }
  };

  if (!run) return <div>Loading...</div>;

  return (
    <div className="page">
      <header className="page-header split">
        <div>
          <h2>{run.title}</h2>
          <p className="muted">status: {run.status} / current: {run.current_stage ?? '-'}</p>
        </div>
        <div className="actions">
          <button onClick={execute} disabled={busy}>{busy ? '실행 중...' : '전체 Execute'}</button>
          <button className="secondary" onClick={retry} disabled={busy}>Reset + Retry</button>
        </div>
      </header>

      <section className="card">
        <h3>사용자 요구</h3>
        <p>{run.user_request}</p>
        {run.final_summary && (
          <>
            <h4>Final Summary</h4>
            <p>{run.final_summary}</p>
          </>
        )}
      </section>

      <section className="card">
        <h3>Step Timeline</h3>
        <RunTimeline steps={run.steps} />
      </section>

      <section className="card">
        <h3>Event Logs</h3>
        <div className="log-list">
          {run.events.map((event) => (
            <div key={event.id} className={`log-item ${event.level}`}>
              <strong>[{event.level}]</strong> {event.message}
              <div className="muted">{new Date(event.created_at).toLocaleString()}</div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
