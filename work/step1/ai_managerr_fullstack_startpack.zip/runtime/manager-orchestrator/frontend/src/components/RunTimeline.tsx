import type { RunStep } from '../types';

export default function RunTimeline({ steps }: { steps: RunStep[] }) {
  return (
    <div className="timeline">
      {steps.map((step) => (
        <div key={step.id} className={`timeline-step ${step.status}`}>
          <div className="timeline-head">
            <strong>{step.seq}. {step.phase}</strong>
            <span className={`badge ${step.status}`}>{step.status}</span>
          </div>
          <div className="muted">agent: {step.agent_code}</div>
          {step.output_text && <pre>{step.output_text}</pre>}
          {step.error_message && <div className="error-box">{step.error_message}</div>}
        </div>
      ))}
    </div>
  );
}
