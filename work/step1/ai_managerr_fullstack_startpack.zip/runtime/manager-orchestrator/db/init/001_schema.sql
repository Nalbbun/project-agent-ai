CREATE TABLE IF NOT EXISTS project (
  id UUID PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  description TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS agent_catalog (
  id UUID PRIMARY KEY,
  code VARCHAR(40) NOT NULL UNIQUE,
  name VARCHAR(120) NOT NULL,
  role VARCHAR(40) NOT NULL,
  endpoint VARCHAR(255) NOT NULL,
  model VARCHAR(120) NOT NULL,
  adapter VARCHAR(120),
  prompt_key VARCHAR(60) NOT NULL,
  active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orchestration_run (
  id UUID PRIMARY KEY,
  project_id UUID REFERENCES project(id),
  title VARCHAR(160) NOT NULL,
  user_request TEXT NOT NULL,
  status VARCHAR(30) NOT NULL,
  current_stage VARCHAR(60),
  final_summary TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orchestration_step (
  id UUID PRIMARY KEY,
  run_id UUID NOT NULL REFERENCES orchestration_run(id) ON DELETE CASCADE,
  seq INTEGER NOT NULL,
  phase VARCHAR(60) NOT NULL,
  agent_code VARCHAR(40) NOT NULL,
  status VARCHAR(30) NOT NULL,
  prompt_text TEXT,
  output_text TEXT,
  input_payload JSONB,
  output_payload JSONB,
  error_message TEXT,
  started_at TIMESTAMP,
  finished_at TIMESTAMP,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS orchestration_event (
  id UUID PRIMARY KEY,
  run_id UUID NOT NULL REFERENCES orchestration_run(id) ON DELETE CASCADE,
  step_id UUID REFERENCES orchestration_step(id) ON DELETE SET NULL,
  level VARCHAR(20) NOT NULL,
  message TEXT NOT NULL,
  payload JSONB,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS artifact (
  id UUID PRIMARY KEY,
  run_id UUID NOT NULL REFERENCES orchestration_run(id) ON DELETE CASCADE,
  step_id UUID REFERENCES orchestration_step(id) ON DELETE SET NULL,
  artifact_type VARCHAR(40) NOT NULL,
  name VARCHAR(120) NOT NULL,
  content JSONB,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_orchestration_run_project ON orchestration_run(project_id);
CREATE INDEX IF NOT EXISTS idx_orchestration_step_run_seq ON orchestration_step(run_id, seq);
CREATE INDEX IF NOT EXISTS idx_orchestration_event_run ON orchestration_event(run_id, created_at);
CREATE INDEX IF NOT EXISTS idx_artifact_run ON artifact(run_id, created_at);
